'use strict';

const winston = require('winston');

const logger = winston.createLogger({
  level: process.env.LOG_LEVEL || 'info',
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.errors({ stack: true }),
    process.env.NODE_ENV === 'production'
      ? winston.format.json()
      : winston.format.combine(winston.format.colorize(), winston.format.simple())
  ),
  transports: [
    new winston.transports.Console(),
    new winston.transports.File({ filename: 'data/logs/error.log', level: 'error' }),
    new winston.transports.File({ filename: 'data/logs/heady.log' }),
  ],
});

module.exports = { logger };
