/* ============================================================
   HeadySystems — app.js
   Smooth scroll, theme toggle, scroll reveal, stats counter
   ============================================================ */

(function () {
  "use strict";

  /* ---- PHI CONSTANTS ---- */
  var PHI = 1.618033988749895;
  void PHI; // referenced for phi-based timing below

  /* ---- THEME TOGGLE ---- */
  var themeToggle = document.querySelector("[data-theme-toggle]");
  var root = document.documentElement;
  var currentTheme = "dark"; // default to dark

  function setTheme(theme) {
    currentTheme = theme;
    root.setAttribute("data-theme", theme);
    if (themeToggle) {
      themeToggle.setAttribute(
        "aria-label",
        "Switch to " + (theme === "dark" ? "light" : "dark") + " mode"
      );
      themeToggle.innerHTML =
        theme === "dark"
          ? '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="5"/><path d="M12 1v2M12 21v2M4.22 4.22l1.42 1.42M18.36 18.36l1.42 1.42M1 12h2M21 12h2M4.22 19.78l1.42-1.42M18.36 5.64l1.42-1.42"/></svg>'
          : '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>';
    }
  }

  setTheme(currentTheme);

  if (themeToggle) {
    themeToggle.addEventListener("click", function () {
      setTheme(currentTheme === "dark" ? "light" : "dark");
    });
  }

  /* ---- MOBILE MENU ---- */
  var mobileMenuBtn = document.getElementById("mobileMenuBtn");
  var navLinks = document.getElementById("navLinks");

  if (mobileMenuBtn && navLinks) {
    mobileMenuBtn.addEventListener("click", function () {
      mobileMenuBtn.classList.toggle("active");
      navLinks.classList.toggle("open");
    });

    // Close on link click
    navLinks.querySelectorAll(".nav-link").forEach(function (link) {
      link.addEventListener("click", function () {
        mobileMenuBtn.classList.remove("active");
        navLinks.classList.remove("open");
      });
    });
  }

  /* ---- HEADER SCROLL BEHAVIOR ---- */
  var header = document.getElementById("header");
  var lastScrollY = 0;
  var ticking = false;

  function updateHeader() {
    var scrollY = window.scrollY;

    if (scrollY > 100) {
      header.classList.add("header--scrolled");
    } else {
      header.classList.remove("header--scrolled");
    }

    if (scrollY > lastScrollY && scrollY > 300) {
      header.classList.add("header--hidden");
    } else {
      header.classList.remove("header--hidden");
    }

    lastScrollY = scrollY;
    ticking = false;
  }

  window.addEventListener(
    "scroll",
    function () {
      if (!ticking) {
        requestAnimationFrame(updateHeader);
        ticking = true;
      }
    },
    { passive: true }
  );

  /* ---- SMOOTH SCROLL FOR NAV LINKS ---- */
  document.querySelectorAll('a[href^="#"]').forEach(function (anchor) {
    anchor.addEventListener("click", function (e) {
      var targetId = this.getAttribute("href");
      if (targetId === "#") return;
      var target = document.querySelector(targetId);
      if (target) {
        e.preventDefault();
        target.scrollIntoView({ behavior: "smooth", block: "start" });
      }
    });
  });

  /* ---- ACTIVE NAV LINK ON SCROLL ---- */
  var sections = document.querySelectorAll("section[id]");
  var navLinksAll = document.querySelectorAll(".nav-link");

  function setActiveNav() {
    var scrollY = window.scrollY + 200;

    sections.forEach(function (section) {
      var sectionTop = section.offsetTop;
      var sectionHeight = section.offsetHeight;
      var sectionId = section.getAttribute("id");

      if (scrollY >= sectionTop && scrollY < sectionTop + sectionHeight) {
        navLinksAll.forEach(function (link) {
          link.classList.remove("active");
          if (link.getAttribute("href") === "#" + sectionId) {
            link.classList.add("active");
          }
        });
      }
    });
  }

  window.addEventListener("scroll", setActiveNav, { passive: true });

  /* ---- SCROLL REVEAL ---- */
  var revealElements = document.querySelectorAll("[data-reveal]");

  if ("IntersectionObserver" in window) {
    var revealObserver = new IntersectionObserver(
      function (entries) {
        entries.forEach(function (entry) {
          if (entry.isIntersecting) {
            entry.target.classList.add("revealed");
            revealObserver.unobserve(entry.target);
          }
        });
      },
      {
        threshold: 0.15,
        rootMargin: "0px 0px -34px 0px",
      }
    );

    revealElements.forEach(function (el) {
      revealObserver.observe(el);
    });
  } else {
    // Fallback: show all
    revealElements.forEach(function (el) {
      el.classList.add("revealed");
    });
  }

  /* ---- TOPOLOGY NODE POSITIONING ---- */
  function positionNodes() {
    var rings = [
      { selector: ".ring-governance .node", radiusPct: 44 },
      { selector: ".ring-outer .node", radiusPct: 35 },
      { selector: ".ring-middle .node", radiusPct: 24 },
      { selector: ".ring-inner .node", radiusPct: 18 },
    ];

    var container = document.querySelector(".topology-container");
    if (!container) return;

    rings.forEach(function (ring) {
      var nodes = container.querySelectorAll(ring.selector);
      nodes.forEach(function (node) {
        var angleDeg = parseFloat(
          node.style.getPropertyValue("--angle") || "0"
        );
        var angleRad = (angleDeg * Math.PI) / 180;
        var x = 50 + ring.radiusPct * Math.cos(angleRad);
        var y = 50 - ring.radiusPct * Math.sin(angleRad);
        node.style.left = x + "%";
        node.style.top = y + "%";
      });
    });

    // Center node
    var centerNode = container.querySelector(".ring-center .node");
    if (centerNode) {
      centerNode.style.left = "50%";
      centerNode.style.top = "50%";
    }
  }

  positionNodes();

  /* ---- STATS COUNTER ANIMATION ---- */
  var statNumbers = document.querySelectorAll(".stat-number[data-count]");

  function animateCounter(el) {
    var target = parseInt(el.getAttribute("data-count"), 10);
    var duration = 1618; // phi-based ms
    var startTime = null;

    function step(timestamp) {
      if (!startTime) startTime = timestamp;
      var progress = Math.min((timestamp - startTime) / duration, 1);
      // Ease out using phi
      var eased = 1 - Math.pow(1 - progress, 2.618);
      el.textContent = Math.round(target * eased);
      if (progress < 1) {
        requestAnimationFrame(step);
      } else {
        el.textContent = target;
      }
    }

    requestAnimationFrame(step);
  }

  if ("IntersectionObserver" in window) {
    var statsObserver = new IntersectionObserver(
      function (entries) {
        entries.forEach(function (entry) {
          if (entry.isIntersecting) {
            animateCounter(entry.target);
            statsObserver.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.5 }
    );

    statNumbers.forEach(function (el) {
      statsObserver.observe(el);
    });
  } else {
    statNumbers.forEach(function (el) {
      el.textContent = el.getAttribute("data-count");
    });
  }
})();
