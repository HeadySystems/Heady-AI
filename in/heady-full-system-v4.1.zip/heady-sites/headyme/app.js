/* ============================================================
   HeadyMe — Your Sovereign AI
   Application Logic: Theme, Nav, Canvas, Scroll Reveals
   ============================================================ */

(function () {
  "use strict";

  /* ---- THEME TOGGLE ---- */
  const themeToggle = document.querySelector("[data-theme-toggle]");
  const root = document.documentElement;
  let currentTheme = "dark";
  root.setAttribute("data-theme", currentTheme);

  function updateToggleIcon() {
    if (!themeToggle) return;
    themeToggle.setAttribute(
      "aria-label",
      "Switch to " + (currentTheme === "dark" ? "light" : "dark") + " mode"
    );
    themeToggle.innerHTML =
      currentTheme === "dark"
        ? '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="5"/><path d="M12 1v2M12 21v2M4.22 4.22l1.42 1.42M18.36 18.36l1.42 1.42M1 12h2M21 12h2M4.22 19.78l1.42-1.42M18.36 5.64l1.42-1.42"/></svg>'
        : '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>';
  }

  updateToggleIcon();

  if (themeToggle) {
    themeToggle.addEventListener("click", function () {
      currentTheme = currentTheme === "dark" ? "light" : "dark";
      root.setAttribute("data-theme", currentTheme);
      updateToggleIcon();
    });
  }

  /* ---- MOBILE MENU ---- */
  const mobileMenuBtn = document.getElementById("mobileMenuBtn");
  const navLinks = document.getElementById("navLinks");

  if (mobileMenuBtn && navLinks) {
    mobileMenuBtn.addEventListener("click", function () {
      mobileMenuBtn.classList.toggle("active");
      navLinks.classList.toggle("mobile-open");
      const isOpen = navLinks.classList.contains("mobile-open");
      mobileMenuBtn.setAttribute(
        "aria-label",
        isOpen ? "Close menu" : "Open menu"
      );
    });

    navLinks.addEventListener("click", function (e) {
      if (e.target.classList.contains("nav-link")) {
        mobileMenuBtn.classList.remove("active");
        navLinks.classList.remove("mobile-open");
      }
    });
  }

  /* ---- HEADER SCROLL BEHAVIOR ---- */
  const header = document.getElementById("header");
  let lastScrollY = 0;
  let ticking = false;

  function updateHeader() {
    const scrollY = window.scrollY;
    if (scrollY > 80) {
      if (scrollY > lastScrollY && scrollY > 200) {
        header.classList.add("header--hidden");
      } else {
        header.classList.remove("header--hidden");
      }
    } else {
      header.classList.remove("header--hidden");
    }
    lastScrollY = scrollY;
    ticking = false;
  }

  window.addEventListener(
    "scroll",
    function () {
      if (!ticking) {
        requestAnimationFrame(updateHeader);
        ticking = true;
      }
    },
    { passive: true }
  );

  /* ---- SCROLL REVEAL FALLBACK ---- */
  /* For browsers that don't support scroll-driven animations */
  if (!CSS.supports("animation-timeline: scroll()")) {
    const revealElements = document.querySelectorAll("[data-reveal]");

    const revealObserver = new IntersectionObserver(
      function (entries) {
        entries.forEach(function (entry) {
          if (entry.isIntersecting) {
            entry.target.classList.add("revealed");
            revealObserver.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.1, rootMargin: "0px 0px -50px 0px" }
    );

    revealElements.forEach(function (el) {
      el.style.opacity = "0";
      revealObserver.observe(el);
    });
  }

  /* ---- GEOMETRIC ANIMATED BACKGROUND (HERO CANVAS) ---- */
  const canvas = document.getElementById("heroCanvas");
  if (canvas) {
    const ctx = canvas.getContext("2d");
    let particles = [];
    let connections = [];
    let animationId;
    let width, height;
    const PHI = 1.618033988749895;
    const particleCount = 60;

    function resize() {
      width = canvas.width = canvas.offsetWidth;
      height = canvas.height = canvas.offsetHeight;
    }

    function createParticles() {
      particles = [];
      for (let i = 0; i < particleCount; i++) {
        const angle = (i / particleCount) * Math.PI * 2 * PHI;
        const radius = Math.sqrt(i / particleCount) * Math.min(width, height) * 0.4;
        particles.push({
          x: width / 2 + Math.cos(angle) * radius + (Math.random() - 0.5) * 100,
          y: height / 2 + Math.sin(angle) * radius + (Math.random() - 0.5) * 100,
          vx: (Math.random() - 0.5) * 0.3,
          vy: (Math.random() - 0.5) * 0.3,
          size: Math.random() * 2 + 1,
          opacity: Math.random() * 0.5 + 0.2,
          type: i % 3 === 0 ? "gold" : "teal",
        });
      }
    }

    function drawParticle(p) {
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
      if (p.type === "gold") {
        ctx.fillStyle = "rgba(212, 160, 23, " + p.opacity + ")";
      } else {
        ctx.fillStyle = "rgba(0, 212, 170, " + p.opacity + ")";
      }
      ctx.fill();
    }

    function drawConnections() {
      const maxDist = 150;
      for (let i = 0; i < particles.length; i++) {
        for (let j = i + 1; j < particles.length; j++) {
          const dx = particles[i].x - particles[j].x;
          const dy = particles[i].y - particles[j].y;
          const dist = Math.sqrt(dx * dx + dy * dy);
          if (dist < maxDist) {
            const alpha = (1 - dist / maxDist) * 0.15;
            ctx.beginPath();
            ctx.moveTo(particles[i].x, particles[i].y);
            ctx.lineTo(particles[j].x, particles[j].y);
            ctx.strokeStyle = "rgba(0, 212, 170, " + alpha + ")";
            ctx.lineWidth = 0.5;
            ctx.stroke();
          }
        }
      }
    }

    function drawGeometry() {
      const cx = width / 2;
      const cy = height / 2;
      const time = Date.now() * 0.0005;

      /* Rotating concentric rings */
      [0.15, 0.25, 0.38].forEach(function (scale, i) {
        const r = Math.min(width, height) * scale;
        const rotation = time * (i % 2 === 0 ? 1 : -1) * 0.3;
        ctx.beginPath();
        ctx.arc(cx, cy, r, 0, Math.PI * 2);
        ctx.strokeStyle = "rgba(0, 212, 170, " + (0.06 - i * 0.015) + ")";
        ctx.lineWidth = 1;
        ctx.stroke();

        /* Hexagonal vertices */
        const sides = 6;
        for (let s = 0; s < sides; s++) {
          const angle = (s / sides) * Math.PI * 2 + rotation;
          const px = cx + Math.cos(angle) * r;
          const py = cy + Math.sin(angle) * r;
          ctx.beginPath();
          ctx.arc(px, py, 2, 0, Math.PI * 2);
          ctx.fillStyle = "rgba(212, 160, 23, " + (0.2 - i * 0.04) + ")";
          ctx.fill();
        }
      });

      /* Golden spiral suggestion */
      ctx.beginPath();
      ctx.strokeStyle = "rgba(212, 160, 23, 0.04)";
      ctx.lineWidth = 1;
      let spiralR = 5;
      let spiralAngle = time * 0.5;
      for (let s = 0; s < 200; s++) {
        const sx = cx + Math.cos(spiralAngle) * spiralR;
        const sy = cy + Math.sin(spiralAngle) * spiralR;
        if (s === 0) {
          ctx.moveTo(sx, sy);
        } else {
          ctx.lineTo(sx, sy);
        }
        spiralR += 0.8;
        spiralAngle += 0.1;
      }
      ctx.stroke();
    }

    function animate() {
      ctx.clearRect(0, 0, width, height);

      drawGeometry();
      drawConnections();

      particles.forEach(function (p) {
        p.x += p.vx;
        p.y += p.vy;

        /* Gentle drift toward center */
        const dx = width / 2 - p.x;
        const dy = height / 2 - p.y;
        const dist = Math.sqrt(dx * dx + dy * dy);
        if (dist > Math.min(width, height) * 0.4) {
          p.vx += dx * 0.00005;
          p.vy += dy * 0.00005;
        }

        /* Boundary wrap */
        if (p.x < 0) p.x = width;
        if (p.x > width) p.x = 0;
        if (p.y < 0) p.y = height;
        if (p.y > height) p.y = 0;

        drawParticle(p);
      });

      animationId = requestAnimationFrame(animate);
    }

    resize();
    createParticles();
    animate();

    window.addEventListener("resize", function () {
      resize();
      createParticles();
    });

    /* Reduce animation when not visible */
    const heroSection = document.getElementById("hero");
    const heroObserver = new IntersectionObserver(
      function (entries) {
        entries.forEach(function (entry) {
          if (entry.isIntersecting) {
            if (!animationId) animate();
          } else {
            cancelAnimationFrame(animationId);
            animationId = null;
          }
        });
      },
      { threshold: 0.1 }
    );

    if (heroSection) {
      heroObserver.observe(heroSection);
    }
  }

  /* ---- SMOOTH SCROLL FOR ANCHOR LINKS ---- */
  document.querySelectorAll('a[href^="#"]').forEach(function (anchor) {
    anchor.addEventListener("click", function (e) {
      const targetId = this.getAttribute("href");
      if (targetId === "#") return;
      const target = document.querySelector(targetId);
      if (target) {
        e.preventDefault();
        target.scrollIntoView({ behavior: "smooth", block: "start" });
      }
    });
  });
})();
