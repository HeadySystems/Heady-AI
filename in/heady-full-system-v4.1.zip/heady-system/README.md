# Heady System v4.0.0 — Sacred Geometry Architecture

> Self-aware, self-correcting AI infrastructure operating in 384-dimensional vector space.

## Architecture Overview

```
┌─────────────────────────────────────────────────────────────┐
│                    Cloudflare Edge Gateway                    │
│         (configs/cloudflare-worker.js — routing + CORS)      │
├──────────┬──────────┬──────────┬──────────┬─────────────────┤
│ /conductor│ /brains  │ /memory  │ /embed   │ /simulate       │
│    ↓      │    ↓     │    ↓     │    ↓     │    ↓            │
│ Cloud Run │ Cloud Run│ Cloud Run│ Colab R1 │ Colab R3        │
│  :3000    │  :3001   │  :3002   │  :5000   │  :5002          │
└──────────┴──────────┴──────────┴──────────┴─────────────────┘
```

### Core Services (Cloud Run)

| Service | Port | Description |
|---------|------|-------------|
| HeadyConductor | 3000 | CSL-gated task classification and routing |
| HeadyBrains | 3001 | Context assembly and enrichment |
| VectorMemory | 3002 | 384D RAM-first vector memory with coherence monitoring |

### Colab Pro+ Runtimes (Latent Space)

| Runtime | Port | Role |
|---------|------|------|
| Runtime 1 | 5000 | Embedding generation (all-MiniLM-L6-v2) |
| Runtime 2 | 5001 | Model serving and inference |
| Runtime 3 | 5002 | Training and Monte Carlo simulation |

### HeadyBee Swarm (30+ Types)

5 critical bees included: health-bee, orchestration-bee, memory-bee, pipeline-bee, telemetry-bee.

## Quick Start

```bash
# Clone and install
git clone <repo-url>
cd heady-system
cp .env.example .env
# Edit .env with your secrets

# Start with Docker Compose
docker compose up -d

# Verify
curl http://localhost:3000/health
curl http://localhost:3001/health
curl http://localhost:3002/health
```

## API Reference

### HeadyConductor (port 3000)

```bash
# Route a task
curl -X POST http://localhost:3000/conductor/route \
  -H "Content-Type: application/json" \
  -d '{"task": "Build a REST API with authentication"}'

# Get routing status
curl http://localhost:3000/conductor/status
```

### HeadyBrains (port 3001)

```bash
# Assemble context for a task
curl -X POST http://localhost:3001/brains/assemble \
  -H "Content-Type: application/json" \
  -d '{"task": "Refactor the authentication middleware"}'
```

### VectorMemory (port 3002)

```bash
# Store a vector
curl -X POST http://localhost:3002/memory/store \
  -H "Content-Type: application/json" \
  -d '{"id": "concept-1", "vector": [0.1, 0.2, ...], "metadata": {"label": "auth"}}'

# Search
curl -X POST http://localhost:3002/memory/search \
  -H "Content-Type: application/json" \
  -d '{"vector": [0.1, 0.2, ...], "topK": 5}'

# Coherence check
curl http://localhost:3002/memory/coherence
```

## Deployment

### Cloud Run

```bash
chmod +x scripts/deploy.sh
./scripts/deploy.sh --project gen-lang-client-0920560496 --region us-east1
```

### Cloudflare Worker

```bash
cd configs
npx wrangler publish cloudflare-worker.js
```

### Colab Runtimes

1. Open `scripts/colab-runtime-setup.py` in Colab Pro+
2. Run all cells
3. Copy the tunnel URL
4. Set `COLAB_RUNTIME_1_URL` in your `.env`
5. Repeat for runtimes 2 and 3

## Environment Variables

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| PORT | No | 3000 | Base port for services |
| NODE_ENV | No | production | Environment |
| DB_HOST | Yes | - | PostgreSQL host |
| DB_PASSWORD | Yes | - | PostgreSQL password |
| JWT_SECRET | Yes | - | JWT signing secret |
| ALLOWED_ORIGINS | No | All Heady domains | CORS origins |
| COLAB_RUNTIME_1_URL | No | - | Runtime 1 tunnel URL |
| COLAB_RUNTIME_2_URL | No | - | Runtime 2 tunnel URL |
| COLAB_RUNTIME_3_URL | No | - | Runtime 3 tunnel URL |
| CLOUDFLARE_ACCOUNT_ID | No | - | Cloudflare account |
| CLOUD_RUN_PROJECT | No | gen-lang-client-0920560496 | GCP project |

## Phi-Math Constants

All system constants derive from the golden ratio (φ ≈ 1.618):

| Constant | Value | Usage |
|----------|-------|-------|
| PHI | 1.618034 | Golden ratio |
| PSI | 0.618034 | Conjugate (1/φ) |
| CSL CRITICAL | 0.927 | Near-certain alignment |
| CSL HIGH | 0.882 | Strong alignment |
| CSL MEDIUM | 0.809 | Moderate (coherence floor) |
| CSL LOW | 0.691 | Weak alignment |
| CSL MINIMUM | 0.500 | Noise floor |
| Pool: Hot | 34% | User-facing resources |
| Pool: Warm | 21% | Background processing |
| Pool: Cold | 13% | Batch/analytics |

## File Structure

```
heady-system/
├── configs/
│   └── cloudflare-worker.js      # Edge gateway
├── scripts/
│   ├── deploy.sh                  # Cloud Run deployment
│   ├── colab-runtime-setup.py     # Runtime 1: embeddings
│   ├── colab-runtime-2.py         # Runtime 2: inference
│   └── colab-runtime-3.py         # Runtime 3: Monte Carlo
├── shared/                        # Foundation modules
│   ├── phi-math.js                # φ constants and functions
│   ├── csl-engine.js              # CSL gate operations
│   ├── logger.js                  # Structured JSON logging
│   ├── health.js                  # Health checks + coherence
│   ├── config.js                  # Validated configuration
│   ├── errors.js                  # Typed error hierarchy
│   ├── middleware.js              # Express middleware
│   ├── circuit-breaker.js         # φ-backoff circuit breaker
│   └── index.js                   # Re-exports
├── src/
│   ├── core/
│   │   ├── conductor.js           # HeadyConductor service
│   │   └── brains.js              # HeadyBrains service
│   ├── memory/
│   │   └── vector-memory.js       # VectorMemory service
│   ├── bees/
│   │   ├── base-bee.js            # BaseHeadyBee abstract class
│   │   ├── bee-factory.js         # BeeFactory + registry
│   │   ├── implementations/
│   │   │   ├── health-bee.js
│   │   │   ├── orchestration-bee.js
│   │   │   ├── memory-bee.js
│   │   │   ├── pipeline-bee.js
│   │   │   └── telemetry-bee.js
│   │   └── index.js               # Bee registration
│   └── index.js                   # Main entry point
├── tests/
│   └── phi-math.test.js           # 36 tests, all passing
├── .env.example
├── docker-compose.yml
├── Dockerfile
├── package.json
└── README.md
```

## 9 Domain Ecosystem

| Domain | Role | Status |
|--------|------|--------|
| headysystems.com | Core Architecture Engine | Live |
| headyme.com | Command Center | Live |
| headyconnection.org | Nonprofit Community Hub | Live |
| headybuddy.org | AI Companion | Live |
| headymcp.com | Protocol Layer | Live |
| headyio.com | Developer Platform | Live |
| headybot.com | Autonomous Automation | Live |
| headyapi.com | Intelligence Interface | Live |
| headyai.com | Intelligence Routing Hub | Building |

---

© 2026 HeadySystems Inc. — Eric Haywood, Founder — 60+ Provisional Patents — Sacred Geometry v4.0
