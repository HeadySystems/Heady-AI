/**
 * @module bees
 * @description HeadyBee agent worker system.
 * Re-exports all bee classes and registers implementations with the global factory.
 */

export { BEE_STATUS, BaseHeadyBee } from './base-bee.js';
export { BeeFactory, globalBeeFactory } from './bee-factory.js';

export { HealthBee } from './implementations/health-bee.js';
export { OrchestrationBee } from './implementations/orchestration-bee.js';
export { MemoryBee } from './implementations/memory-bee.js';
export { PipelineBee } from './implementations/pipeline-bee.js';
export { TelemetryBee } from './implementations/telemetry-bee.js';

// --- Register all bee implementations with the global factory ---

import { globalBeeFactory } from './bee-factory.js';
import { HealthBee } from './implementations/health-bee.js';
import { OrchestrationBee } from './implementations/orchestration-bee.js';
import { MemoryBee } from './implementations/memory-bee.js';
import { PipelineBee } from './implementations/pipeline-bee.js';
import { TelemetryBee } from './implementations/telemetry-bee.js';

globalBeeFactory.register('health', HealthBee);
globalBeeFactory.register('orchestration', OrchestrationBee);
globalBeeFactory.register('memory', MemoryBee);
globalBeeFactory.register('pipeline', PipelineBee);
globalBeeFactory.register('telemetry', TelemetryBee);
