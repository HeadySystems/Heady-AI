/**
 * @module health-bee
 * @description HeadyBee implementation for health checking service endpoints.
 * Spawns with a list of service endpoints, fetches /health from each,
 * aggregates coherence scores, and flags degraded services.
 */

import { BaseHeadyBee } from '../base-bee.js';
import { CSL_THRESHOLDS } from '../../../shared/phi-math.js';
import { createLogger } from '../../../shared/logger.js';

const log = createLogger('health-bee');

/**
 * Health-check bee.
 * Monitors service endpoints and computes aggregate coherence.
 *
 * @example
 * const bee = new HealthBee({ name: 'health-monitor' });
 * const result = await bee.run(
 *   { endpoints: ['http://svc-a:3000', 'http://svc-b:3001'] }
 * );
 */
export class HealthBee extends BaseHeadyBee {
  constructor(config) {
    super({ ...config, type: config.type || 'health' });

    /** @type {string[]} List of service base URLs to check. */
    this._endpoints = [];

    /** @type {Array<{endpoint: string, status: string, coherenceScore: number, durationMs: number, error: string|null}>} */
    this._results = [];

    /** @type {{healthy: number, degraded: number, unhealthy: number, avgCoherence: number, flagged: string[]}} */
    this._report = null;
  }

  /**
   * Initialize the list of service endpoints to check.
   * @param {*} context - Optional context (unused, endpoints come from task).
   * @returns {Promise<void>}
   */
  async spawn(context) {
    this._endpoints = [];
    this._results = [];
    this._report = null;
    log.debug({ bee: this.name }, `${this.name} spawned, ready to accept endpoint list`);
  }

  /**
   * Fetch /health from each endpoint and collect results.
   * Uses native fetch (Node 18+). Each request has individual timeout handling.
   * @param {Object} task - Task payload.
   * @param {string[]} task.endpoints - Array of service base URLs.
   * @returns {Promise<void>}
   */
  async execute(task) {
    this._endpoints = task.endpoints || [];

    if (this._endpoints.length === 0) {
      log.warn({ bee: this.name }, `${this.name}: no endpoints to check`);
      return;
    }

    const checkEndpoint = async (endpoint) => {
      const url = endpoint.endsWith('/health') ? endpoint : `${endpoint}/health`;
      const start = Date.now();

      try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), this.timeout);

        const response = await fetch(url, { signal: controller.signal });
        clearTimeout(timeoutId);

        const body = await response.json();
        const durationMs = Date.now() - start;

        return {
          endpoint,
          status: body.status || (response.ok ? 'healthy' : 'unhealthy'),
          coherenceScore: typeof body.coherenceScore === 'number' ? body.coherenceScore : (response.ok ? 1.0 : 0.0),
          durationMs,
          error: null,
        };
      } catch (err) {
        return {
          endpoint,
          status: 'unhealthy',
          coherenceScore: 0,
          durationMs: Date.now() - start,
          error: err.name === 'AbortError' ? 'Timeout' : err.message,
        };
      }
    };

    this._results = await Promise.all(this._endpoints.map(checkEndpoint));
    log.info(
      { bee: this.name, checked: this._results.length },
      `${this.name}: checked ${this._results.length} endpoints`
    );
  }

  /**
   * Aggregate coherence scores and flag any below CSL_THRESHOLDS.MEDIUM.
   * @returns {Promise<{healthy: number, degraded: number, unhealthy: number, avgCoherence: number, flagged: string[], results: Array}>}
   */
  async report() {
    const total = this._results.length;

    if (total === 0) {
      this._report = {
        healthy: 0,
        degraded: 0,
        unhealthy: 0,
        avgCoherence: 0,
        flagged: [],
        results: [],
      };
      return this._report;
    }

    let healthy = 0;
    let degraded = 0;
    let unhealthy = 0;
    let coherenceSum = 0;
    const flagged = [];

    for (const result of this._results) {
      coherenceSum += result.coherenceScore;

      if (result.coherenceScore < CSL_THRESHOLDS.MEDIUM) {
        flagged.push(result.endpoint);
      }

      if (result.status === 'healthy') {
        healthy++;
      } else if (result.status === 'degraded') {
        degraded++;
      } else {
        unhealthy++;
      }
    }

    this._report = {
      healthy,
      degraded,
      unhealthy,
      avgCoherence: parseFloat((coherenceSum / total).toFixed(4)),
      flagged,
      results: this._results,
    };

    if (flagged.length > 0) {
      log.warn(
        { bee: this.name, flagged, threshold: CSL_THRESHOLDS.MEDIUM },
        `${this.name}: ${flagged.length} endpoint(s) below MEDIUM coherence threshold`
      );
    }

    return this._report;
  }

  /**
   * Clear endpoint list and results.
   * @returns {Promise<void>}
   */
  async retire() {
    const endpointCount = this._endpoints.length;
    this._endpoints = [];
    this._results = [];
    log.debug({ bee: this.name, cleared: endpointCount }, `${this.name} retired, cleared ${endpointCount} endpoints`);
  }
}
