/**
 * @module orchestration-bee
 * @description HeadyBee implementation for orchestrating DAGs of subtasks.
 * Parses a task into a directed acyclic graph of subtasks with dependencies,
 * performs topological sort, and executes independent subtasks concurrently.
 */

import { BaseHeadyBee } from '../base-bee.js';
import { createLogger } from '../../../shared/logger.js';

const log = createLogger('orchestration-bee');

/**
 * @typedef {Object} SubTask
 * @property {string} id - Unique subtask identifier.
 * @property {string} name - Human-readable subtask name.
 * @property {string[]} dependencies - Array of subtask IDs this depends on.
 * @property {(inputs: Record<string, *>) => Promise<*>} handler - Async execution function.
 *   Receives a map of dependency ID → result.
 */

/**
 * Orchestration bee.
 * Manages a DAG of subtasks with dependency resolution and concurrent execution.
 *
 * @example
 * const bee = new OrchestrationBee({ name: 'pipeline-orch' });
 * await bee.run({
 *   subtasks: [
 *     { id: 'a', name: 'Fetch data', dependencies: [], handler: async () => data },
 *     { id: 'b', name: 'Transform', dependencies: ['a'], handler: async ({ a }) => transform(a) },
 *     { id: 'c', name: 'Load', dependencies: ['b'], handler: async ({ b }) => load(b) },
 *   ]
 * });
 */
export class OrchestrationBee extends BaseHeadyBee {
  constructor(config) {
    super({ ...config, type: config.type || 'orchestration' });

    /** @type {SubTask[]} Parsed subtask list. */
    this._subtasks = [];

    /** @type {string[][]} Topologically sorted execution layers. */
    this._executionLayers = [];

    /** @type {Map<string, *>} Results keyed by subtask ID. */
    this._resultMap = new Map();

    /** @type {Array<{id: string, name: string, status: string, durationMs: number, error: string|null}>} */
    this._subtaskResults = [];
  }

  /**
   * Parse the task into a DAG and compute topological sort layers.
   * @param {*} context - Optional context (unused).
   * @returns {Promise<void>}
   */
  async spawn(context) {
    this._subtasks = [];
    this._executionLayers = [];
    this._resultMap = new Map();
    this._subtaskResults = [];
    log.debug({ bee: this.name }, `${this.name} spawned, ready to accept subtask DAG`);
  }

  /**
   * Topologically sort the DAG and execute independent subtasks concurrently.
   * @param {Object} task - Task payload.
   * @param {SubTask[]} task.subtasks - Array of subtask definitions.
   * @returns {Promise<void>}
   * @throws {Error} If the DAG contains a cycle.
   */
  async execute(task) {
    this._subtasks = task.subtasks || [];

    if (this._subtasks.length === 0) {
      log.warn({ bee: this.name }, `${this.name}: no subtasks to orchestrate`);
      return;
    }

    // Build adjacency and in-degree maps
    this._executionLayers = this._topologicalSort(this._subtasks);

    // Build handler lookup
    const handlerMap = new Map();
    for (const st of this._subtasks) {
      handlerMap.set(st.id, st);
    }

    // Execute layer by layer — all subtasks within a layer run concurrently
    for (const layer of this._executionLayers) {
      const layerPromises = layer.map(async (subtaskId) => {
        const subtask = handlerMap.get(subtaskId);
        const start = Date.now();

        // Gather dependency results
        const inputs = {};
        for (const depId of subtask.dependencies) {
          inputs[depId] = this._resultMap.get(depId);
        }

        try {
          const result = await subtask.handler(inputs);
          this._resultMap.set(subtaskId, result);
          this._subtaskResults.push({
            id: subtaskId,
            name: subtask.name,
            status: 'completed',
            durationMs: Date.now() - start,
            error: null,
          });
        } catch (err) {
          this._resultMap.set(subtaskId, null);
          this._subtaskResults.push({
            id: subtaskId,
            name: subtask.name,
            status: 'failed',
            durationMs: Date.now() - start,
            error: err.message,
          });
          log.error(
            { bee: this.name, subtask: subtaskId, error: err.message },
            `${this.name}: subtask "${subtaskId}" failed: ${err.message}`
          );
        }
      });

      await Promise.all(layerPromises);
    }

    log.info(
      { bee: this.name, total: this._subtasks.length, layers: this._executionLayers.length },
      `${this.name}: executed ${this._subtasks.length} subtasks in ${this._executionLayers.length} layers`
    );
  }

  /**
   * Collect all subtask results into a summary.
   * @returns {Promise<{totalSubtasks: number, completed: number, failed: number, layers: number, subtasks: Array, results: Record<string, *>}>}
   */
  async report() {
    const completed = this._subtaskResults.filter((r) => r.status === 'completed').length;
    const failed = this._subtaskResults.filter((r) => r.status === 'failed').length;

    const results = {};
    for (const [key, value] of this._resultMap) {
      results[key] = value;
    }

    return {
      totalSubtasks: this._subtasks.length,
      completed,
      failed,
      layers: this._executionLayers.length,
      subtasks: this._subtaskResults,
      results,
    };
  }

  /**
   * Cleanup subtask references.
   * @returns {Promise<void>}
   */
  async retire() {
    const count = this._subtasks.length;
    this._subtasks = [];
    this._executionLayers = [];
    this._resultMap = new Map();
    this._subtaskResults = [];
    log.debug({ bee: this.name, cleared: count }, `${this.name} retired, cleared ${count} subtask references`);
  }

  /**
   * Kahn's algorithm for topological sort, returning execution layers.
   * Each layer contains subtask IDs that can run concurrently.
   * @param {SubTask[]} subtasks - Subtask definitions.
   * @returns {string[][]} Array of layers, each containing subtask IDs.
   * @throws {Error} If a cycle is detected.
   * @private
   */
  _topologicalSort(subtasks) {
    const inDegree = new Map();
    const adjacency = new Map();
    const ids = new Set();

    for (const st of subtasks) {
      ids.add(st.id);
      if (!inDegree.has(st.id)) inDegree.set(st.id, 0);
      if (!adjacency.has(st.id)) adjacency.set(st.id, []);

      for (const dep of st.dependencies) {
        if (!adjacency.has(dep)) adjacency.set(dep, []);
        adjacency.get(dep).push(st.id);
        inDegree.set(st.id, (inDegree.get(st.id) || 0) + 1);
      }
    }

    const layers = [];
    let queue = [];

    // Seed with zero in-degree nodes
    for (const id of ids) {
      if ((inDegree.get(id) || 0) === 0) {
        queue.push(id);
      }
    }

    let processed = 0;

    while (queue.length > 0) {
      layers.push([...queue]);
      const nextQueue = [];

      for (const id of queue) {
        processed++;
        for (const neighbor of (adjacency.get(id) || [])) {
          const newDeg = inDegree.get(neighbor) - 1;
          inDegree.set(neighbor, newDeg);
          if (newDeg === 0) {
            nextQueue.push(neighbor);
          }
        }
      }

      queue = nextQueue;
    }

    if (processed !== ids.size) {
      throw new Error(`Cycle detected in subtask DAG: processed ${processed} of ${ids.size} subtasks`);
    }

    return layers;
  }
}
