/**
 * @module memory-bee
 * @description HeadyBee implementation for vector memory operations.
 * Provides store, search, and coherence operations against an in-memory
 * vector store reference (simulating a VectorMemory service connection).
 */

import { BaseHeadyBee } from '../base-bee.js';
import { cosineSimilarity } from '../../../shared/csl-engine.js';
import { DEDUP_THRESHOLD, CSL_THRESHOLDS } from '../../../shared/phi-math.js';
import { createLogger } from '../../../shared/logger.js';

const log = createLogger('memory-bee');

/**
 * @typedef {Object} VectorEntry
 * @property {string} id - Unique entry identifier.
 * @property {number[]} vector - Embedding vector.
 * @property {Object} metadata - Associated metadata.
 * @property {string} createdAt - ISO timestamp.
 */

/**
 * Memory bee.
 * Performs vector operations (store, search, coherence check) against
 * an in-memory vector store.
 *
 * @example
 * const bee = new MemoryBee({ name: 'mem-worker' });
 * await bee.run({
 *   operation: 'search',
 *   vector: queryEmbedding,
 *   topK: 5,
 * });
 */
export class MemoryBee extends BaseHeadyBee {
  constructor(config) {
    super({ ...config, type: config.type || 'memory' });

    /** @type {VectorEntry[]} In-memory vector store. */
    this._store = [];

    /** @type {VectorEntry[]} Pending entries to flush. */
    this._pendingWrites = [];

    /** @type {*} Result of the last operation. */
    this._operationResult = null;

    /** @type {boolean} Whether the store is connected. */
    this._connected = false;
  }

  /**
   * Connect to the VectorMemory service (in-memory reference).
   * Optionally pre-loads existing vectors from context.
   * @param {Object} [context] - Optional context.
   * @param {VectorEntry[]} [context.existingVectors] - Pre-existing vectors to load.
   * @returns {Promise<void>}
   */
  async spawn(context) {
    this._store = [];
    this._pendingWrites = [];
    this._operationResult = null;

    if (context?.existingVectors && Array.isArray(context.existingVectors)) {
      this._store = [...context.existingVectors];
      log.info(
        { bee: this.name, loaded: this._store.length },
        `${this.name}: loaded ${this._store.length} existing vectors`
      );
    }

    this._connected = true;
    log.debug({ bee: this.name }, `${this.name} connected to vector memory`);
  }

  /**
   * Perform a vector operation based on task.operation.
   *
   * Supported operations:
   * - 'store': Add a vector entry. task.id, task.vector, task.metadata required.
   * - 'search': Find top-K nearest neighbors. task.vector, task.topK required.
   * - 'coherence': Compute coherence score between task.vector and all stored vectors.
   *
   * @param {Object} task - Operation task.
   * @param {'store'|'search'|'coherence'} task.operation - Operation type.
   * @param {string} [task.id] - Entry ID (for store).
   * @param {number[]} [task.vector] - Embedding vector.
   * @param {Object} [task.metadata] - Entry metadata (for store).
   * @param {number} [task.topK=5] - Number of results (for search).
   * @returns {Promise<void>}
   * @throws {Error} If operation is unknown or store is not connected.
   */
  async execute(task) {
    if (!this._connected) {
      throw new Error(`${this.name}: not connected to vector memory`);
    }

    switch (task.operation) {
      case 'store':
        this._operationResult = this._executeStore(task);
        break;
      case 'search':
        this._operationResult = this._executeSearch(task);
        break;
      case 'coherence':
        this._operationResult = this._executeCoherence(task);
        break;
      default:
        throw new Error(`${this.name}: unknown operation "${task.operation}"`);
    }

    log.info(
      { bee: this.name, operation: task.operation },
      `${this.name}: completed ${task.operation} operation`
    );
  }

  /**
   * Return the operation results.
   * @returns {Promise<*>} Operation-specific result.
   */
  async report() {
    return this._operationResult;
  }

  /**
   * Flush pending write operations and disconnect.
   * @returns {Promise<void>}
   */
  async retire() {
    // Flush any pending writes into the main store
    if (this._pendingWrites.length > 0) {
      this._store.push(...this._pendingWrites);
      log.info(
        { bee: this.name, flushed: this._pendingWrites.length },
        `${this.name}: flushed ${this._pendingWrites.length} pending writes`
      );
      this._pendingWrites = [];
    }

    this._connected = false;
    log.debug(
      { bee: this.name, totalStored: this._store.length },
      `${this.name} retired, ${this._store.length} vectors in store`
    );
  }

  /**
   * Store a vector entry. Checks for deduplication.
   * @param {Object} task - Store task.
   * @returns {{stored: boolean, id: string, duplicate: boolean, duplicateOf: string|null}}
   * @private
   */
  _executeStore(task) {
    const { id, vector, metadata = {} } = task;

    // Deduplication check: skip if cosine similarity exceeds DEDUP_THRESHOLD
    for (const existing of this._store) {
      const sim = cosineSimilarity(vector, existing.vector);
      if (sim >= DEDUP_THRESHOLD) {
        log.debug(
          { bee: this.name, id, duplicateOf: existing.id, similarity: sim },
          `${this.name}: duplicate detected (${sim.toFixed(4)} >= ${DEDUP_THRESHOLD})`
        );
        return { stored: false, id, duplicate: true, duplicateOf: existing.id };
      }
    }

    const entry = {
      id,
      vector,
      metadata,
      createdAt: new Date().toISOString(),
    };

    this._pendingWrites.push(entry);
    return { stored: true, id, duplicate: false, duplicateOf: null };
  }

  /**
   * Search for top-K nearest neighbors by cosine similarity.
   * @param {Object} task - Search task.
   * @returns {{query: number[], results: Array<{id: string, score: number, metadata: Object}>}}
   * @private
   */
  _executeSearch(task) {
    const { vector, topK = 5 } = task;

    // Include pending writes in search
    const allEntries = [...this._store, ...this._pendingWrites];

    const scored = allEntries.map((entry) => ({
      id: entry.id,
      score: cosineSimilarity(vector, entry.vector),
      metadata: entry.metadata,
    }));

    scored.sort((a, b) => b.score - a.score);
    const results = scored.slice(0, topK);

    return { query: vector, results };
  }

  /**
   * Compute coherence score for a vector against the entire store.
   * Returns average cosine similarity and flags entries below MEDIUM threshold.
   * @param {Object} task - Coherence task.
   * @returns {{avgCoherence: number, totalEntries: number, belowThreshold: Array<{id: string, score: number}>}}
   * @private
   */
  _executeCoherence(task) {
    const { vector } = task;
    const allEntries = [...this._store, ...this._pendingWrites];

    if (allEntries.length === 0) {
      return { avgCoherence: 0, totalEntries: 0, belowThreshold: [] };
    }

    let total = 0;
    const belowThreshold = [];

    for (const entry of allEntries) {
      const score = cosineSimilarity(vector, entry.vector);
      total += score;

      if (score < CSL_THRESHOLDS.MEDIUM) {
        belowThreshold.push({ id: entry.id, score: parseFloat(score.toFixed(4)) });
      }
    }

    const avgCoherence = parseFloat((total / allEntries.length).toFixed(4));

    return {
      avgCoherence,
      totalEntries: allEntries.length,
      belowThreshold,
    };
  }
}
