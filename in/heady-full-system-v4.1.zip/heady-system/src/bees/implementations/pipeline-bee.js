/**
 * @module pipeline-bee
 * @description HeadyBee implementation for sequential pipeline processing.
 * Runs a chain of named stages (context, classify, route, execute, quality,
 * assurance, pattern, story), passing output of each stage to the next.
 */

import { BaseHeadyBee } from '../base-bee.js';
import { createLogger } from '../../../shared/logger.js';

const log = createLogger('pipeline-bee');

/**
 * Default pipeline stage names in execution order.
 * @type {readonly string[]}
 */
const DEFAULT_STAGES = Object.freeze([
  'context',
  'classify',
  'route',
  'execute',
  'quality',
  'assurance',
  'pattern',
  'story',
]);

/**
 * @typedef {Object} StageResult
 * @property {string} stage - Stage name.
 * @property {*} output - Stage output data.
 * @property {number} durationMs - Execution time in ms.
 * @property {string} status - 'completed' or 'failed'.
 * @property {string|null} error - Error message if failed.
 */

/**
 * Pipeline bee.
 * Runs stages sequentially, threading output through the chain.
 *
 * @example
 * const bee = new PipelineBee({ name: 'ingest-pipeline' });
 * await bee.run({
 *   input: rawData,
 *   handlers: {
 *     context: async (input) => enrichContext(input),
 *     classify: async (input) => classifyIntent(input),
 *     // ...
 *   }
 * });
 */
export class PipelineBee extends BaseHeadyBee {
  constructor(config) {
    super({ ...config, type: config.type || 'pipeline' });

    /** @type {string[]} Ordered stage names. */
    this._stages = [];

    /** @type {StageResult[]} Results from each stage. */
    this._stageResults = [];

    /** @type {*} Final pipeline output. */
    this._finalOutput = null;
  }

  /**
   * Initialize pipeline stages.
   * @param {Object} [context] - Optional context.
   * @param {string[]} [context.stages] - Custom stage order. Defaults to DEFAULT_STAGES.
   * @returns {Promise<void>}
   */
  async spawn(context) {
    this._stages = (context?.stages && Array.isArray(context.stages))
      ? [...context.stages]
      : [...DEFAULT_STAGES];
    this._stageResults = [];
    this._finalOutput = null;

    log.info(
      { bee: this.name, stages: this._stages },
      `${this.name}: initialized pipeline with ${this._stages.length} stages: [${this._stages.join(', ')}]`
    );
  }

  /**
   * Run stages sequentially, passing each stage's output to the next.
   *
   * @param {Object} task - Task payload.
   * @param {*} task.input - Initial input for the first stage.
   * @param {Record<string, (input: *) => Promise<*>>} [task.handlers] - Map of stage name to handler function.
   *   If a handler is not provided for a stage, the input passes through unchanged.
   * @returns {Promise<void>}
   */
  async execute(task) {
    let current = task.input;
    const handlers = task.handlers || {};

    for (const stage of this._stages) {
      const start = Date.now();
      const handler = handlers[stage];

      if (typeof handler !== 'function') {
        // Pass-through: no handler for this stage
        this._stageResults.push({
          stage,
          output: current,
          durationMs: Date.now() - start,
          status: 'completed',
          error: null,
        });
        log.debug({ bee: this.name, stage }, `${this.name}: stage "${stage}" pass-through (no handler)`);
        continue;
      }

      try {
        const output = await handler(current);
        const durationMs = Date.now() - start;

        this._stageResults.push({
          stage,
          output,
          durationMs,
          status: 'completed',
          error: null,
        });

        current = output;
        log.debug(
          { bee: this.name, stage, durationMs },
          `${this.name}: stage "${stage}" completed in ${durationMs}ms`
        );
      } catch (err) {
        const durationMs = Date.now() - start;

        this._stageResults.push({
          stage,
          output: null,
          durationMs,
          status: 'failed',
          error: err.message,
        });

        log.error(
          { bee: this.name, stage, error: err.message },
          `${this.name}: stage "${stage}" failed: ${err.message}`
        );

        // Pipeline halts on stage failure
        throw new Error(`Pipeline halted at stage "${stage}": ${err.message}`);
      }
    }

    this._finalOutput = current;
    log.info(
      { bee: this.name, stagesCompleted: this._stageResults.length },
      `${this.name}: pipeline completed all ${this._stageResults.length} stages`
    );
  }

  /**
   * Return pipeline execution summary with per-stage timing.
   * @returns {Promise<{stages: StageResult[], totalDurationMs: number, stagesCompleted: number, stagesFailed: number, finalOutput: *}>}
   */
  async report() {
    const totalDurationMs = this._stageResults.reduce((sum, r) => sum + r.durationMs, 0);
    const completed = this._stageResults.filter((r) => r.status === 'completed').length;
    const failed = this._stageResults.filter((r) => r.status === 'failed').length;

    return {
      stages: this._stageResults.map(({ stage, durationMs, status, error }) => ({
        stage,
        durationMs,
        status,
        error,
      })),
      totalDurationMs,
      stagesCompleted: completed,
      stagesFailed: failed,
      finalOutput: this._finalOutput,
    };
  }

  /**
   * Clear stage results and references.
   * @returns {Promise<void>}
   */
  async retire() {
    const stageCount = this._stages.length;
    this._stages = [];
    this._stageResults = [];
    this._finalOutput = null;
    log.debug({ bee: this.name, cleared: stageCount }, `${this.name} retired, cleared ${stageCount} stage results`);
  }
}
