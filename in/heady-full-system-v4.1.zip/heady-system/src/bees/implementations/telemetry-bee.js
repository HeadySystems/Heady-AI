/**
 * @module telemetry-bee
 * @description HeadyBee implementation for collecting and aggregating telemetry.
 * Gathers metrics from target bees, computes aggregates (total, averages, error rates),
 * and produces a telemetry summary report.
 */

import { BaseHeadyBee } from '../base-bee.js';
import { createLogger } from '../../../shared/logger.js';

const log = createLogger('telemetry-bee');

/**
 * @typedef {Object} BeeMetric
 * @property {string} name - Bee name.
 * @property {string} type - Bee type.
 * @property {string} status - Bee status at collection time.
 * @property {number} executionMs - Execution duration in ms.
 * @property {boolean} errored - Whether the bee encountered an error.
 * @property {string|null} error - Error message if errored.
 * @property {number} collectedAt - Unix timestamp of metric collection.
 */

/**
 * Telemetry bee.
 * Collects metrics from bee run results and computes aggregate statistics.
 *
 * @example
 * const bee = new TelemetryBee({ name: 'metrics-collector' });
 * await bee.run({
 *   targets: [
 *     { name: 'health-1', type: 'health', status: 'COMPLETE', timings: { execute: 150 }, error: null },
 *     { name: 'orch-1', type: 'orchestration', status: 'FAILED', timings: { execute: 3200 }, error: 'timeout' },
 *   ]
 * });
 */
export class TelemetryBee extends BaseHeadyBee {
  constructor(config) {
    super({ ...config, type: config.type || 'telemetry' });

    /** @type {BeeMetric[]} Collected metrics. */
    this._metrics = [];

    /** @type {{totalBees: number, avgExecutionMs: number, errorRate: number, byType: Record<string, {count: number, avgMs: number, errors: number}>}|null} */
    this._summary = null;
  }

  /**
   * Initialize metrics collection arrays.
   * @param {*} [context] - Optional context (unused).
   * @returns {Promise<void>}
   */
  async spawn(context) {
    this._metrics = [];
    this._summary = null;
    log.debug({ bee: this.name }, `${this.name} spawned, ready to collect telemetry`);
  }

  /**
   * Collect metrics from target bee results.
   *
   * @param {Object} task - Task payload.
   * @param {Array<{name: string, type: string, status: string, timings?: Record<string, number>, error?: string|null}>} task.targets
   *   Array of bee run results (as returned by BaseHeadyBee.run()).
   * @returns {Promise<void>}
   */
  async execute(task) {
    const targets = task.targets || [];

    if (targets.length === 0) {
      log.warn({ bee: this.name }, `${this.name}: no targets to collect metrics from`);
      return;
    }

    const collectedAt = Date.now();

    for (const target of targets) {
      const timings = target.timings || {};
      // Sum all phase timings for total execution time
      const executionMs = Object.values(timings).reduce((sum, t) => sum + (typeof t === 'number' ? t : 0), 0);
      const errored = target.status === 'FAILED' || !!target.error;

      this._metrics.push({
        name: target.name,
        type: target.type,
        status: target.status,
        executionMs,
        errored,
        error: target.error || null,
        collectedAt,
      });
    }

    // Compute aggregate statistics
    const totalBees = this._metrics.length;
    const totalMs = this._metrics.reduce((sum, m) => sum + m.executionMs, 0);
    const errorCount = this._metrics.filter((m) => m.errored).length;
    const avgExecutionMs = totalBees > 0 ? parseFloat((totalMs / totalBees).toFixed(2)) : 0;
    const errorRate = totalBees > 0 ? parseFloat((errorCount / totalBees).toFixed(4)) : 0;

    // Group by type
    const byType = {};
    for (const metric of this._metrics) {
      if (!byType[metric.type]) {
        byType[metric.type] = { count: 0, totalMs: 0, errors: 0 };
      }
      byType[metric.type].count++;
      byType[metric.type].totalMs += metric.executionMs;
      if (metric.errored) byType[metric.type].errors++;
    }

    // Compute per-type averages
    for (const type of Object.keys(byType)) {
      const entry = byType[type];
      entry.avgMs = parseFloat((entry.totalMs / entry.count).toFixed(2));
      delete entry.totalMs;
    }

    this._summary = {
      totalBees,
      avgExecutionMs,
      errorRate,
      byType,
    };

    log.info(
      { bee: this.name, totalBees, avgExecutionMs, errorRate },
      `${this.name}: collected metrics for ${totalBees} bees (avg ${avgExecutionMs}ms, error rate ${(errorRate * 100).toFixed(1)}%)`
    );
  }

  /**
   * Return the telemetry summary.
   * @returns {Promise<{totalBees: number, avgExecutionMs: number, errorRate: number, byType: Record<string, {count: number, avgMs: number, errors: number}>, metrics: BeeMetric[]}>}
   */
  async report() {
    return {
      ...(this._summary || { totalBees: 0, avgExecutionMs: 0, errorRate: 0, byType: {} }),
      metrics: [...this._metrics],
    };
  }

  /**
   * Flush collected metrics.
   * @returns {Promise<void>}
   */
  async retire() {
    const count = this._metrics.length;
    this._metrics = [];
    this._summary = null;
    log.debug({ bee: this.name, flushed: count }, `${this.name} retired, flushed ${count} metrics`);
  }
}
