/**
 * @module bee-factory
 * @description Factory for creating HeadyBee instances by type.
 * Supports registration of bee classes and instantiation by type string.
 */

import { createLogger } from '../../shared/logger.js';

const log = createLogger('bee-factory');

/**
 * Factory for registering and instantiating HeadyBee classes.
 *
 * @example
 * const factory = new BeeFactory();
 * factory.register('health', HealthBee);
 * const bee = factory.create('health', { name: 'health-checker' });
 */
export class BeeFactory {
  constructor() {
    /** @type {Map<string, typeof import('./base-bee.js').BaseHeadyBee>} */
    this._registry = new Map();
  }

  /**
   * Register a bee class under a type name.
   * @param {string} beeType - Type identifier (e.g. 'health', 'orchestration').
   * @param {typeof import('./base-bee.js').BaseHeadyBee} BeeClass - Bee class constructor.
   * @throws {Error} If beeType is already registered.
   */
  register(beeType, BeeClass) {
    if (this._registry.has(beeType)) {
      throw new Error(`Bee type "${beeType}" is already registered`);
    }
    this._registry.set(beeType, BeeClass);
    log.info({ beeType }, `Registered bee type: ${beeType}`);
  }

  /**
   * Create a bee instance of the given type.
   * @param {string} beeType - Registered type identifier.
   * @param {Object} [config={}] - Configuration passed to the bee constructor.
   *   The `type` field will be set automatically.
   * @returns {import('./base-bee.js').BaseHeadyBee} New bee instance.
   * @throws {Error} If beeType is not registered.
   */
  create(beeType, config = {}) {
    const BeeClass = this._registry.get(beeType);
    if (!BeeClass) {
      throw new Error(`Unknown bee type "${beeType}". Registered: [${this.list().join(', ')}]`);
    }
    const bee = new BeeClass({ ...config, type: beeType });
    log.debug({ beeType, name: bee.name, id: bee.id }, `Created bee: ${bee.name} [${beeType}]`);
    return bee;
  }

  /**
   * List all registered bee type names.
   * @returns {string[]} Array of registered type names.
   */
  list() {
    return Array.from(this._registry.keys());
  }

  /**
   * Check if a bee type is registered.
   * @param {string} beeType - Type identifier to check.
   * @returns {boolean} True if registered.
   */
  has(beeType) {
    return this._registry.has(beeType);
  }
}

/**
 * Global singleton BeeFactory instance.
 * All standard bee types should be registered here.
 * @type {BeeFactory}
 */
export const globalBeeFactory = new BeeFactory();
