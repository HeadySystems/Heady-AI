/**
 * @module base-bee
 * @description Abstract base class for all HeadyBee agent workers.
 * Defines the lifecycle: spawn → execute → report → retire.
 * Every concrete bee must override all four lifecycle methods.
 */

import { PHI, FIB } from '../../shared/phi-math.js';
import { createLogger } from '../../shared/logger.js';
import { randomUUID } from 'node:crypto';

const log = createLogger('heady-bee');

/**
 * Bee lifecycle status enum.
 * @type {Readonly<{IDLE: string, SPAWNING: string, EXECUTING: string, REPORTING: string, RETIRING: string, FAILED: string, COMPLETE: string}>}
 */
export const BEE_STATUS = Object.freeze({
  IDLE: 'IDLE',
  SPAWNING: 'SPAWNING',
  EXECUTING: 'EXECUTING',
  REPORTING: 'REPORTING',
  RETIRING: 'RETIRING',
  FAILED: 'FAILED',
  COMPLETE: 'COMPLETE',
});

/**
 * Valid lifecycle transitions.
 * @type {Record<string, string>}
 */
const TRANSITIONS = {
  [BEE_STATUS.IDLE]: BEE_STATUS.SPAWNING,
  [BEE_STATUS.SPAWNING]: BEE_STATUS.EXECUTING,
  [BEE_STATUS.EXECUTING]: BEE_STATUS.REPORTING,
  [BEE_STATUS.REPORTING]: BEE_STATUS.RETIRING,
  [BEE_STATUS.RETIRING]: BEE_STATUS.COMPLETE,
};

/**
 * Abstract base class for HeadyBee workers.
 *
 * Subclasses MUST override: spawn(), execute(), report(), retire().
 *
 * @example
 * class MyBee extends BaseHeadyBee {
 *   async spawn(context) { ... }
 *   async execute(task)  { ... }
 *   async report()       { ... }
 *   async retire()       { ... }
 * }
 */
export class BaseHeadyBee {
  /**
   * @param {Object} config - Bee configuration.
   * @param {string} config.name - Unique name for this bee instance.
   * @param {string} config.type - Bee type identifier (e.g. 'health', 'orchestration').
   * @param {number} [config.timeout] - Execution timeout in ms. Default: Math.round(PHI * 1000) = 1618ms.
   * @param {number} [config.maxRetries] - Maximum retry attempts. Default: FIB[6] = 8.
   */
  constructor(config) {
    if (new.target === BaseHeadyBee) {
      throw new Error('BaseHeadyBee is abstract and cannot be instantiated directly');
    }

    /** @type {string} Unique bee instance identifier. */
    this.id = randomUUID();

    /** @type {string} Human-readable name. */
    this.name = config.name;

    /** @type {string} Bee type identifier. */
    this.type = config.type;

    /** @type {string} Current lifecycle status. */
    this.status = BEE_STATUS.IDLE;

    /** @type {number} Execution timeout in milliseconds. */
    this.timeout = config.timeout ?? Math.round(PHI * 1000); // 1618ms

    /** @type {number} Maximum retry attempts. */
    this.maxRetries = config.maxRetries ?? FIB[6]; // 8

    /** @type {string} ISO timestamp of creation. */
    this.createdAt = new Date().toISOString();

    /** @type {*} Result from the report phase. */
    this._result = null;

    /** @type {Error|null} Error if the bee failed. */
    this._error = null;

    /** @type {Object} Timing data for each lifecycle phase. */
    this._timings = {};
  }

  /**
   * Transition to a new status. Validates the transition is legal.
   * @param {string} newStatus - Target status.
   * @throws {Error} If the transition is invalid.
   */
  _transition(newStatus) {
    if (newStatus === BEE_STATUS.FAILED) {
      // Any state can transition to FAILED
      log.info(
        { bee: this.name, type: this.type, from: this.status, to: newStatus },
        `Bee ${this.name} [${this.type}]: ${this.status} -> ${newStatus}`
      );
      this.status = newStatus;
      return;
    }

    const expected = TRANSITIONS[this.status];
    if (expected !== newStatus) {
      throw new Error(
        `Invalid transition for bee ${this.name}: ${this.status} -> ${newStatus} (expected ${expected || 'none'})`
      );
    }

    log.info(
      { bee: this.name, type: this.type, from: this.status, to: newStatus },
      `Bee ${this.name} [${this.type}]: ${this.status} -> ${newStatus}`
    );
    this.status = newStatus;
  }

  /**
   * Initialize the bee with context. Transition: IDLE → SPAWNING.
   * MUST be overridden by subclasses.
   * @param {*} context - Initialization context.
   * @returns {Promise<void>}
   * @abstract
   */
  async spawn(context) {
    throw new Error(`${this.constructor.name} must implement spawn()`);
  }

  /**
   * Execute the bee's primary task. Transition: SPAWNING → EXECUTING.
   * MUST be overridden by subclasses.
   * @param {*} task - Task payload.
   * @returns {Promise<*>} Task result.
   * @abstract
   */
  async execute(task) {
    throw new Error(`${this.constructor.name} must implement execute()`);
  }

  /**
   * Compile and return the bee's results. Transition: EXECUTING → REPORTING.
   * MUST be overridden by subclasses.
   * @returns {Promise<*>} Report data.
   * @abstract
   */
  async report() {
    throw new Error(`${this.constructor.name} must implement report()`);
  }

  /**
   * Clean up resources. Transition: REPORTING → RETIRING → COMPLETE.
   * MUST be overridden by subclasses.
   * @returns {Promise<void>}
   * @abstract
   */
  async retire() {
    throw new Error(`${this.constructor.name} must implement retire()`);
  }

  /**
   * Run the full bee lifecycle: spawn → execute → report → retire.
   * Catches errors at any phase, sets FAILED status, and logs.
   *
   * @param {*} task - Task payload (passed to execute).
   * @param {*} [context] - Initialization context (passed to spawn).
   * @returns {Promise<{id: string, name: string, type: string, status: string, result: *, error: string|null, timings: Object, createdAt: string}>}
   */
  async run(task, context) {
    const phases = [
      { name: 'spawn', fn: () => this.spawn(context) },
      { name: 'execute', fn: () => this.execute(task) },
      { name: 'report', fn: () => this.report() },
      { name: 'retire', fn: () => this.retire() },
    ];

    const statusForPhase = {
      spawn: BEE_STATUS.SPAWNING,
      execute: BEE_STATUS.EXECUTING,
      report: BEE_STATUS.REPORTING,
      retire: BEE_STATUS.RETIRING,
    };

    try {
      for (const phase of phases) {
        this._transition(statusForPhase[phase.name]);
        const start = Date.now();

        const result = await Promise.race([
          phase.fn(),
          new Promise((_, reject) =>
            setTimeout(() => reject(new Error(`Timeout in ${phase.name} after ${this.timeout}ms`)), this.timeout)
          ),
        ]);

        this._timings[phase.name] = Date.now() - start;

        if (phase.name === 'report') {
          this._result = result;
        }
      }

      this._transition(BEE_STATUS.COMPLETE);
    } catch (err) {
      this._error = err;
      this._transition(BEE_STATUS.FAILED);
      log.error(
        { bee: this.name, type: this.type, error: err.message, phase: this.status },
        `Bee ${this.name} [${this.type}] failed: ${err.message}`
      );
    }

    return {
      id: this.id,
      name: this.name,
      type: this.type,
      status: this.status,
      result: this._result,
      error: this._error?.message || null,
      timings: { ...this._timings },
      createdAt: this.createdAt,
    };
  }
}
