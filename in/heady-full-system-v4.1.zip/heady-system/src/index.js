/**
 * @module index
 * Heady System — Main entry point.
 * Starts HeadyConductor, HeadyBrains, and VectorMemory services.
 */

import { createConductorService } from './core/conductor.js';
import { createBrainsService } from './core/brains.js';
import { createVectorMemoryService } from './memory/vector-memory.js';
import { globalBeeFactory } from './bees/index.js';
import { createLogger } from '../shared/logger.js';

const logger = createLogger('HeadySystem');

const BASE_PORT = parseInt(process.env.PORT || '3000', 10);
const CONDUCTOR_PORT = BASE_PORT;
const BRAINS_PORT = BASE_PORT + 1;
const MEMORY_PORT = BASE_PORT + 2;

/** @type {import('http').Server[]} */
const servers = [];

/**
 * Start all Heady services.
 */
async function start() {
  logger.info('Starting Heady System v4.0.0');

  const conductorApp = createConductorService();
  const brainsApp = createBrainsService();
  const memoryApp = createVectorMemoryService();

  const conductorServer = conductorApp.listen(CONDUCTOR_PORT, () => {
    logger.info(`HeadyConductor listening on port ${CONDUCTOR_PORT}`);
  });
  servers.push(conductorServer);

  const brainsServer = brainsApp.listen(BRAINS_PORT, () => {
    logger.info(`HeadyBrains listening on port ${BRAINS_PORT}`);
  });
  servers.push(brainsServer);

  const memoryServer = memoryApp.listen(MEMORY_PORT, () => {
    logger.info(`VectorMemory listening on port ${MEMORY_PORT}`);
  });
  servers.push(memoryServer);

  const beeTypes = globalBeeFactory.list();
  logger.info(`Registered ${beeTypes.length} bee types: ${beeTypes.join(', ')}`);

  logger.info('Heady System started', {
    conductor: `http://0.0.0.0:${CONDUCTOR_PORT}`,
    brains: `http://0.0.0.0:${BRAINS_PORT}`,
    memory: `http://0.0.0.0:${MEMORY_PORT}`,
    beeTypes: beeTypes.length,
  });
}

/**
 * Graceful shutdown — LIFO order (memory, brains, conductor).
 * @param {string} signal - The signal received.
 */
async function shutdown(signal) {
  logger.info(`Received ${signal}, shutting down gracefully`);

  for (let i = servers.length - 1; i >= 0; i--) {
    const server = servers[i];
    await new Promise((resolve) => {
      server.close(() => {
        logger.info(`Server ${i} closed`);
        resolve();
      });
    });
  }

  logger.info('All services stopped');
  process.exit(0);
}

process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));

start().catch((err) => {
  logger.error('Failed to start Heady System', { error: err.message, stack: err.stack });
  process.exit(1);
});
