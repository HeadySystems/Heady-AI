/**
 * @module vector-memory
 * @description 384D vector memory service — RAM-first with pgvector backup.
 * Provides cosine-similarity search, coherence monitoring, and Express REST API.
 */

import express from 'express';
import { cosineSimilarity } from '../../shared/csl-engine.js';
import { CSL_THRESHOLDS, FIB } from '../../shared/phi-math.js';
import { createLogger } from '../../shared/logger.js';
import { ValidationError, NotFoundError } from '../../shared/errors.js';
import {
  corsMiddleware,
  securityHeaders,
  correlationId,
  rateLimiter,
  errorHandler,
} from '../../shared/middleware.js';

const log = createLogger('VectorMemory');

/**
 * @typedef {Object} VectorEntry
 * @property {string} id - Unique identifier.
 * @property {Float64Array} vector - Embedding vector.
 * @property {object} metadata - Arbitrary metadata.
 * @property {string} timestamp - ISO 8601 creation timestamp.
 * @property {number} coherenceScore - Per-entry coherence score (default 1.0).
 */

/**
 * In-memory 384D vector store with cosine similarity search and coherence monitoring.
 */
export class VectorMemory {
  /**
   * @param {object} [opts] - Configuration options.
   * @param {number} [opts.dimension=384] - Vector dimensionality.
   */
  constructor(opts = {}) {
    /** @type {number} */
    this.dimension = opts.dimension || 384;

    /** @type {Map<string, VectorEntry>} */
    this._store = new Map();

    /** @type {{stored: number, searched: number, deleted: number}} */
    this._stats = { stored: 0, searched: 0, deleted: 0 };

    log.info({ dimension: this.dimension }, 'VectorMemory initialized');
  }

  /**
   * Number of vectors currently stored.
   * @returns {number}
   */
  get size() {
    return this._store.size;
  }

  /**
   * Store a vector with metadata.
   *
   * @param {string} id - Unique identifier for the vector.
   * @param {number[]|Float64Array} vector - Embedding vector (must match dimension).
   * @param {object} [metadata={}] - Arbitrary metadata to attach.
   * @returns {VectorEntry} The stored entry.
   * @throws {ValidationError} If vector dimension is incorrect or inputs are invalid.
   */
  store(id, vector, metadata = {}) {
    if (!id || typeof id !== 'string') {
      throw new ValidationError('id must be a non-empty string');
    }

    if (!vector || vector.length !== this.dimension) {
      throw new ValidationError(
        `Vector must have exactly ${this.dimension} dimensions, got ${vector?.length ?? 0}`
      );
    }

    const entry = {
      id,
      vector: Float64Array.from(vector),
      metadata,
      timestamp: new Date().toISOString(),
      coherenceScore: 1.0,
    };

    this._store.set(id, entry);
    this._stats.stored++;

    log.debug({ id, metadataKeys: Object.keys(metadata) }, 'Vector stored');
    return entry;
  }

  /**
   * Search for the most similar vectors to a query.
   *
   * @param {number[]|Float64Array} queryVector - Query embedding.
   * @param {number} [topK=5] - Maximum number of results.
   * @param {number} [threshold=0.500] - Minimum cosine similarity threshold.
   * @returns {Array<{id: string, score: number, metadata: object}>} Results sorted by score descending.
   * @throws {ValidationError} If query vector dimension is incorrect.
   */
  search(queryVector, topK = 5, threshold = CSL_THRESHOLDS.MINIMUM) {
    if (!queryVector || queryVector.length !== this.dimension) {
      throw new ValidationError(
        `Query vector must have exactly ${this.dimension} dimensions, got ${queryVector?.length ?? 0}`
      );
    }

    this._stats.searched++;
    const queryArr = Array.from(queryVector);
    const results = [];

    for (const [, entry] of this._store) {
      const score = cosineSimilarity(queryArr, Array.from(entry.vector));
      if (score >= threshold) {
        results.push({ id: entry.id, score, metadata: entry.metadata });
      }
    }

    results.sort((a, b) => b.score - a.score);
    return results.slice(0, topK);
  }

  /**
   * Retrieve a vector entry by ID.
   *
   * @param {string} id - Entry identifier.
   * @returns {VectorEntry|null} The entry, or null if not found.
   */
  get(id) {
    return this._store.get(id) || null;
  }

  /**
   * Delete a vector entry by ID.
   *
   * @param {string} id - Entry identifier.
   * @returns {boolean} True if an entry was deleted, false if not found.
   */
  delete(id) {
    const deleted = this._store.delete(id);
    if (deleted) {
      this._stats.deleted++;
      log.debug({ id }, 'Vector deleted');
    }
    return deleted;
  }

  /**
   * Compute average pairwise cosine similarity across stored vectors.
   * If the store has more than 100 items, samples 55 (Fibonacci) random pairs.
   *
   * @returns {{coherenceScore: number, vectorCount: number, sampledPairs: number, timestamp: string}}
   */
  coherenceCheck() {
    const ids = Array.from(this._store.keys());
    const count = ids.length;
    const timestamp = new Date().toISOString();

    if (count < 2) {
      return { coherenceScore: 1.0, vectorCount: count, sampledPairs: 0, timestamp };
    }

    const sampleSize = FIB[10]; // 55
    const needsSampling = count > 100;

    let totalSim = 0;
    let pairs = 0;

    if (needsSampling) {
      // Sample 55 random pairs
      for (let p = 0; p < sampleSize; p++) {
        const i = Math.floor(Math.random() * count);
        let j = Math.floor(Math.random() * (count - 1));
        if (j >= i) j++;

        const a = this._store.get(ids[i]);
        const b = this._store.get(ids[j]);
        totalSim += cosineSimilarity(Array.from(a.vector), Array.from(b.vector));
        pairs++;
      }
    } else {
      // Exhaustive pairwise comparison
      for (let i = 0; i < count; i++) {
        for (let j = i + 1; j < count; j++) {
          const a = this._store.get(ids[i]);
          const b = this._store.get(ids[j]);
          totalSim += cosineSimilarity(Array.from(a.vector), Array.from(b.vector));
          pairs++;
        }
      }
    }

    const coherenceScore = pairs > 0 ? totalSim / pairs : 1.0;

    return {
      coherenceScore: parseFloat(coherenceScore.toFixed(6)),
      vectorCount: count,
      sampledPairs: pairs,
      timestamp,
    };
  }

  /**
   * Run a coherence check and log a warning if the score falls below MEDIUM threshold.
   *
   * @returns {{coherenceScore: number, vectorCount: number, sampledPairs: number, timestamp: string}}
   */
  heartbeat() {
    const result = this.coherenceCheck();

    if (result.coherenceScore < CSL_THRESHOLDS.MEDIUM) {
      log.warn(
        { coherenceScore: result.coherenceScore, threshold: CSL_THRESHOLDS.MEDIUM, vectorCount: result.vectorCount },
        `Coherence drift detected: ${result.coherenceScore.toFixed(4)} < ${CSL_THRESHOLDS.MEDIUM}`
      );
    } else {
      log.debug(
        { coherenceScore: result.coherenceScore, vectorCount: result.vectorCount },
        'Heartbeat OK'
      );
    }

    return result;
  }

  /**
   * Remove all stored vectors and reset stats.
   */
  clear() {
    this._store.clear();
    this._stats = { stored: 0, searched: 0, deleted: 0 };
    log.info(null, 'VectorMemory cleared');
  }
}

/**
 * Create an Express application for the VectorMemory service.
 *
 * Routes:
 * - POST   /memory/store     — Store a vector: body {id, vector, metadata?}
 * - POST   /memory/search    — Search vectors: body {vector, topK?, threshold?}
 * - GET    /memory/:id       — Retrieve a vector by ID
 * - DELETE /memory/:id       — Delete a vector by ID
 * - GET    /memory/coherence — Run coherence check
 * - GET    /health           — Health endpoint with coherence score
 *
 * @param {object} [opts] - Options passed to VectorMemory constructor.
 * @returns {import('express').Application} Configured Express app.
 */
export function createVectorMemoryService(opts = {}) {
  const memory = new VectorMemory(opts);
  const app = express();

  // --- Middleware ---
  app.use(express.json({ limit: '2mb' }));
  app.use(corsMiddleware);
  app.use(securityHeaders);
  app.use(correlationId);
  app.use(rateLimiter());

  // --- Routes ---

  /**
   * POST /memory/store
   * Store a vector embedding with optional metadata.
   * Body: { id: string, vector: number[], metadata?: object }
   */
  app.post('/memory/store', (req, res, next) => {
    try {
      const { id, vector, metadata } = req.body;

      if (!id || typeof id !== 'string') {
        throw new ValidationError('Body must include "id" as a non-empty string');
      }
      if (!Array.isArray(vector)) {
        throw new ValidationError('Body must include "vector" as a number array');
      }

      const entry = memory.store(id, vector, metadata || {});

      res.status(201).json({
        stored: true,
        id: entry.id,
        dimension: entry.vector.length,
        timestamp: entry.timestamp,
      });
    } catch (err) {
      next(err);
    }
  });

  /**
   * POST /memory/search
   * Search for similar vectors.
   * Body: { vector: number[], topK?: number, threshold?: number }
   */
  app.post('/memory/search', (req, res, next) => {
    try {
      const { vector, topK, threshold } = req.body;

      if (!Array.isArray(vector)) {
        throw new ValidationError('Body must include "vector" as a number array');
      }

      const results = memory.search(
        vector,
        topK !== undefined ? topK : 5,
        threshold !== undefined ? threshold : CSL_THRESHOLDS.MINIMUM,
      );

      res.json({
        results,
        count: results.length,
        vectorCount: memory.size,
      });
    } catch (err) {
      next(err);
    }
  });

  /**
   * GET /memory/coherence
   * Run a coherence check across stored vectors.
   */
  app.get('/memory/coherence', (_req, res) => {
    const result = memory.heartbeat();
    res.json(result);
  });

  /**
   * GET /memory/:id
   * Retrieve a vector entry by ID.
   */
  app.get('/memory/:id', (req, res, next) => {
    try {
      const entry = memory.get(req.params.id);
      if (!entry) {
        throw new NotFoundError(`Vector "${req.params.id}" not found`);
      }
      res.json({
        id: entry.id,
        vector: Array.from(entry.vector),
        metadata: entry.metadata,
        timestamp: entry.timestamp,
        coherenceScore: entry.coherenceScore,
      });
    } catch (err) {
      next(err);
    }
  });

  /**
   * DELETE /memory/:id
   * Delete a vector entry by ID.
   */
  app.delete('/memory/:id', (req, res, next) => {
    try {
      const deleted = memory.delete(req.params.id);
      if (!deleted) {
        throw new NotFoundError(`Vector "${req.params.id}" not found`);
      }
      res.json({ deleted: true, id: req.params.id });
    } catch (err) {
      next(err);
    }
  });

  /**
   * GET /health
   * Health check with coherence score.
   */
  app.get('/health', (_req, res) => {
    const coherence = memory.coherenceCheck();
    const status = coherence.coherenceScore >= CSL_THRESHOLDS.MEDIUM
      ? 'healthy'
      : coherence.coherenceScore >= CSL_THRESHOLDS.MINIMUM
        ? 'degraded'
        : 'unhealthy';

    res.status(status === 'healthy' ? 200 : status === 'degraded' ? 207 : 503).json({
      status,
      service: 'VectorMemory',
      vectorCount: memory.size,
      coherenceScore: coherence.coherenceScore,
      coherenceThreshold: CSL_THRESHOLDS.MEDIUM,
      stats: memory._stats,
      uptime: Math.floor(process.uptime()),
    });
  });

  // --- Error handler ---
  app.use(errorHandler);

  // Expose memory instance for testing / programmatic access
  app._memory = memory;
  return app;
}
