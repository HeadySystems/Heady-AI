/**
 * @module brains
 * @description HeadyBrains — context assembly service.
 * Assembles enriched context for a task before the Conductor routes it.
 * Detects complexity, domain hints, and generates placeholder embeddings.
 */

import express from 'express';
import { randomUUID } from 'node:crypto';
import { PHI, PSI, CSL_THRESHOLDS, phiFusionWeights } from '../../shared/phi-math.js';
import { normalize, cosineSimilarity } from '../../shared/csl-engine.js';
import { createLogger } from '../../shared/logger.js';
import { createHealthCheck } from '../../shared/health.js';
import { ValidationError } from '../../shared/errors.js';
import {
  corsMiddleware, securityHeaders, correlationId, errorHandler,
} from '../../shared/middleware.js';

const log = createLogger('HeadyBrains');

/** Embedding dimensionality for context vectors. */
const EMBEDDING_DIM = 384;

/**
 * Domain keyword map for hint detection.
 * Keys are domain labels; values are arrays of keywords to scan for.
 * @type {Record<string, string[]>}
 */
const DOMAIN_KEYWORDS = {
  code:      ['code', 'function', 'class', 'module', 'implement', 'build', 'compile', 'refactor', 'debug', 'test', 'api', 'endpoint'],
  security:  ['security', 'vulnerability', 'exploit', 'auth', 'encrypt', 'cipher', 'threat', 'penetration', 'firewall', 'permission'],
  research:  ['research', 'investigate', 'study', 'explore', 'analyze', 'survey', 'literature', 'paper', 'hypothesis'],
  creative:  ['creative', 'brainstorm', 'design', 'ui', 'ux', 'visual', 'concept', 'prototype', 'sketch', 'brand'],
  data:      ['data', 'database', 'query', 'sql', 'analytics', 'metric', 'report', 'dashboard', 'dataset', 'pipeline'],
  devops:    ['deploy', 'ci', 'cd', 'docker', 'kubernetes', 'infra', 'terraform', 'pipeline', 'monitoring', 'scaling'],
  docs:      ['document', 'readme', 'wiki', 'guide', 'tutorial', 'manual', 'jsdoc', 'changelog', 'specification'],
};

/**
 * Complexity keywords that increase the complexity estimate when present.
 * @type {string[]}
 */
const COMPLEXITY_BOOSTERS = [
  'integrate', 'migrate', 'distributed', 'concurrent', 'async', 'real-time',
  'optimize', 'architecture', 'microservice', 'multi-tenant', 'authentication',
  'authorization', 'encryption', 'streaming', 'pipeline', 'orchestrat',
];

/**
 * Generate a random unit vector of the given dimension.
 * Placeholder until real embedding model is wired.
 * @param {number} dim - Vector dimensionality.
 * @returns {number[]} Normalized random vector.
 */
function randomUnitVector(dim) {
  const v = new Array(dim);
  for (let i = 0; i < dim; i++) {
    // Box-Muller for normally distributed components (better unit sphere distribution)
    const u1 = Math.random() || 1e-10;
    const u2 = Math.random();
    v[i] = Math.sqrt(-2 * Math.log(u1)) * Math.cos(2 * Math.PI * u2);
  }
  return normalize(v);
}

/**
 * Estimate task complexity from description length and keyword density.
 * @param {string} task - Task description.
 * @returns {'simple'|'medium'|'complex'} Complexity tier.
 */
function estimateComplexity(task) {
  const len = task.length;
  const lower = task.toLowerCase();
  const boosterHits = COMPLEXITY_BOOSTERS.filter((kw) => lower.includes(kw)).length;

  // Base complexity from length
  if (len < 50 && boosterHits === 0) return 'simple';
  if (len > 200 || boosterHits >= 3) return 'complex';
  if (len >= 50 || boosterHits >= 1) return 'medium';
  return 'simple';
}

/**
 * Detect domain hints from the task description by scanning for keywords.
 * @param {string} task - Task description.
 * @returns {string[]} Array of matched domain labels.
 */
function detectDomainHints(task) {
  const lower = task.toLowerCase();
  const hints = [];
  for (const [domain, keywords] of Object.entries(DOMAIN_KEYWORDS)) {
    const hits = keywords.filter((kw) => lower.includes(kw)).length;
    if (hits > 0) {
      hints.push(domain);
    }
  }
  return hints;
}

/**
 * HeadyBrains — context assembly engine.
 * Enriches raw task descriptions with embeddings, complexity estimates,
 * domain hints, and metadata before handing off to the Conductor.
 */
export class HeadyBrains {
  /**
   * Initialize the HeadyBrains context assembler.
   * Sets up context cache and internal counters.
   */
  constructor() {
    /** @type {Map<string, object>} Cache of recently assembled contexts keyed by contextId. */
    this.contextCache = new Map();
    /** Embedding vector dimensionality. */
    this.embeddingDim = EMBEDDING_DIM;
    /** Total number of context assemblies performed. */
    this.totalAssemblies = 0;
    /** Service start time for uptime calculation. */
    this.startTime = Date.now();

    log.info({ embeddingDim: this.embeddingDim }, 'HeadyBrains initialized');
  }

  /**
   * Assemble enriched context for a task description.
   *
   * Generates a placeholder embedding (384D random unit vector),
   * estimates complexity, detects domain hints, and bundles
   * everything into a context object for downstream processing.
   *
   * @param {string} taskDescription - The raw task string.
   * @returns {Promise<{
   *   contextId: string,
   *   taskDescription: string,
   *   taskEmbedding: number[],
   *   complexity: 'simple'|'medium'|'complex',
   *   domainHints: string[],
   *   memoryReferences: any[],
   *   timestamp: string,
   * }>} Enriched context object.
   */
  async assembleContext(taskDescription) {
    const contextId = `ctx-${randomUUID()}`;
    const taskEmbedding = randomUnitVector(this.embeddingDim);
    const complexity = estimateComplexity(taskDescription);
    const domainHints = detectDomainHints(taskDescription);

    const context = {
      contextId,
      taskDescription,
      taskEmbedding,
      complexity,
      domainHints,
      memoryReferences: [],
      timestamp: new Date().toISOString(),
    };

    this.contextCache.set(contextId, context);
    this.totalAssemblies++;

    log.info({
      contextId,
      complexity,
      domainHints,
      taskPreview: taskDescription.slice(0, 80),
    }, 'Context assembled');

    return context;
  }

  /**
   * Get the current service status.
   * @returns {{cacheSize: number, totalAssemblies: number, uptimeMs: number}}
   */
  getStatus() {
    return {
      cacheSize: this.contextCache.size,
      totalAssemblies: this.totalAssemblies,
      uptimeMs: Date.now() - this.startTime,
    };
  }
}

/**
 * Create an Express application for the HeadyBrains service.
 * @returns {import('express').Application} The configured Express app.
 */
export function createBrainsService() {
  const brains = new HeadyBrains();
  const app = express();

  app.use(express.json());
  app.use(corsMiddleware);
  app.use(securityHeaders);
  app.use(correlationId);

  /**
   * POST /brains/assemble
   * Assemble enriched context for a task.
   * Body: { task: string }
   */
  app.post('/brains/assemble', async (req, res, next) => {
    try {
      const { task } = req.body;
      if (!task || typeof task !== 'string') {
        throw new ValidationError('Request body must include a "task" string');
      }
      const context = await brains.assembleContext(task);
      res.json(context);
    } catch (err) {
      next(err);
    }
  });

  /**
   * GET /brains/status
   * Returns cache size, total assemblies, and uptime.
   */
  app.get('/brains/status', (_req, res) => {
    res.json(brains.getStatus());
  });

  /**
   * GET /health
   * Health check endpoint with coherence scoring.
   */
  app.get('/health', createHealthCheck({
    service: 'HeadyBrains',
    version: '4.0.0',
    coherenceThreshold: CSL_THRESHOLDS.MEDIUM,
    checks: [
      {
        name: 'context-cache',
        check: async () => ({ ok: true, detail: { size: brains.contextCache.size } }),
      },
      {
        name: 'embedding-dim',
        check: async () => ({
          ok: brains.embeddingDim === EMBEDDING_DIM,
          detail: { dim: brains.embeddingDim },
        }),
      },
    ],
  }));

  app.use(errorHandler);

  app._brains = brains;
  return app;
}
