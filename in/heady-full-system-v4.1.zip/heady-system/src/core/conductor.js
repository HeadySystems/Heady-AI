/**
 * @module conductor
 * HeadyConductor — the central orchestration authority.
 * Every task flows through it: classify domain, select pool, route to nodes.
 */

import express from 'express';
import {
  PHI, CSL_THRESHOLDS, phiResourceWeights,
} from '../../shared/phi-math.js';
import { normalize, cosineSimilarity, cslGATE } from '../../shared/csl-engine.js';
import { createLogger } from '../../shared/logger.js';
import { createHealthCheck } from '../../shared/health.js';
import { ValidationError } from '../../shared/errors.js';
import {
  corsMiddleware, securityHeaders, correlationId, errorHandler,
} from '../../shared/middleware.js';

/**
 * Generate a random unit vector of the given dimension.
 * @param {number} dim - Vector dimensionality.
 * @returns {number[]} Normalized random vector.
 */
function randomUnitVector(dim) {
  const v = new Array(dim);
  for (let i = 0; i < dim; i++) {
    const u1 = Math.random() || 1e-10;
    const u2 = Math.random();
    v[i] = Math.sqrt(-2 * Math.log(u1)) * Math.cos(2 * Math.PI * u2);
  }
  return normalize(v);
}

const log = createLogger('HeadyConductor');

/**
 * @typedef {Object} DomainEntry
 * @property {string} domain - The domain name.
 * @property {string[]} nodes - Node names in this domain.
 * @property {string} pool - Pool assignment (hot, warm, cold).
 * @property {Float64Array} embedding - 384D domain embedding vector.
 */

/** Domain routing table with task types mapped to node pools. */
const DOMAIN_TABLE = [
  { domain: 'code_generation', nodes: ['JULES', 'BUILDER', 'HeadyCoder'], pool: 'hot' },
  { domain: 'code_review', nodes: ['OBSERVER', 'HeadyAnalyze'], pool: 'hot' },
  { domain: 'security', nodes: ['MURPHY', 'CIPHER', 'HeadyRisks'], pool: 'hot' },
  { domain: 'architecture', nodes: ['ATLAS', 'PYTHIA', 'HeadyVinci'], pool: 'hot' },
  { domain: 'research', nodes: ['HeadyResearch', 'SOPHIA'], pool: 'warm' },
  { domain: 'documentation', nodes: ['ATLAS', 'HeadyCodex'], pool: 'warm' },
  { domain: 'creative', nodes: ['MUSE', 'NOVA'], pool: 'warm' },
  { domain: 'monitoring', nodes: ['OBSERVER', 'LENS', 'SENTINEL'], pool: 'warm' },
  { domain: 'cleanup', nodes: ['JANITOR', 'HeadyMaid'], pool: 'cold' },
  { domain: 'analytics', nodes: ['HeadyPatterns', 'HeadyMC'], pool: 'cold' },
];

/** Pool resource allocation (phi-derived: hot=34%, warm=21%, cold=13%, reserve=8%, governance=5%) */
const POOL_ALLOCATION = Object.freeze({
  hot: 0.34,
  warm: 0.21,
  cold: 0.13,
  reserve: 0.08,
  governance: 0.05,
});

/** Keyword hints for faster classification before falling back to vector similarity. */
const DOMAIN_KEYWORDS = {
  code_generation: ['code', 'generate', 'build', 'implement', 'create', 'write', 'function', 'class', 'module', 'component', 'program'],
  code_review: ['review', 'audit', 'inspect', 'check', 'lint', 'quality', 'refactor', 'analyze code'],
  security: ['security', 'vulnerability', 'exploit', 'cve', 'encrypt', 'auth', 'penetration', 'threat', 'cipher', 'risk'],
  architecture: ['architecture', 'design', 'pattern', 'system', 'scalability', 'infrastructure', 'diagram', 'topology'],
  research: ['research', 'investigate', 'study', 'explore', 'learn', 'discover', 'analyze', 'survey'],
  documentation: ['document', 'readme', 'wiki', 'guide', 'tutorial', 'manual', 'api doc', 'jsdoc'],
  creative: ['creative', 'brainstorm', 'innovate', 'ui', 'ux', 'design', 'visual', 'concept'],
  monitoring: ['monitor', 'observe', 'alert', 'metric', 'log', 'trace', 'dashboard', 'health'],
  cleanup: ['clean', 'remove', 'delete', 'deprecate', 'archive', 'tidy', 'sweep', 'prune'],
  analytics: ['analytics', 'statistics', 'report', 'trend', 'pattern', 'insight', 'data'],
};

/**
 * HeadyConductor — the central orchestration authority for task routing.
 */
export class HeadyConductor {
  /**
   * @param {object} [opts] - Configuration options.
   * @param {number} [opts.embeddingDim=384] - Embedding dimensionality.
   */
  constructor(opts = {}) {
    this.embeddingDim = opts.embeddingDim || 384;
    this.routingTable = DOMAIN_TABLE.map((entry) => ({
      ...entry,
      embedding: randomUnitVector(this.embeddingDim),
    }));
    this.poolAllocation = POOL_ALLOCATION;
    this.routeCount = 0;
    this.startTime = Date.now();
    log.info('HeadyConductor initialized', {
      domains: this.routingTable.length,
      embeddingDim: this.embeddingDim,
    });
  }

  /**
   * Classify a task description into a domain using keyword matching
   * gated by CSL cosine similarity against domain embeddings.
   * @param {string} taskDescription - The task to classify.
   * @returns {{ domain: string, confidence: number, pool: string, nodes: string[] }}
   */
  classifyTask(taskDescription) {
    const lowerTask = taskDescription.toLowerCase();
    const taskEmbedding = randomUnitVector(this.embeddingDim);

    let bestDomain = null;
    let bestScore = -Infinity;

    for (const entry of this.routingTable) {
      const keywords = DOMAIN_KEYWORDS[entry.domain] || [];
      const keywordHits = keywords.filter((kw) => lowerTask.includes(kw)).length;
      const keywordScore = keywords.length > 0 ? keywordHits / keywords.length : 0;

      const vectorScore = cosineSimilarity(taskEmbedding, entry.embedding);
      const gatedKeywordScore = cslGATE(keywordScore, vectorScore, CSL_THRESHOLDS.MINIMUM);
      const combinedScore = gatedKeywordScore * PHI + Math.abs(vectorScore);

      if (combinedScore > bestScore) {
        bestScore = combinedScore;
        bestDomain = entry;
      }
    }

    if (!bestDomain) {
      bestDomain = this.routingTable[0];
      bestScore = 0;
    }

    const confidence = Math.min(bestScore / (PHI + 1), 1);

    log.info('Task classified', {
      domain: bestDomain.domain,
      pool: bestDomain.pool,
      confidence: confidence.toFixed(4),
      taskPreview: taskDescription.slice(0, 80),
    });

    return {
      domain: bestDomain.domain,
      confidence,
      pool: bestDomain.pool,
      nodes: bestDomain.nodes,
    };
  }

  /**
   * Route a task: classify it and return the full routing decision.
   * @param {string} taskDescription - The task to route.
   * @returns {{ routeId: string, classification: object, allocation: number, timestamp: string }}
   */
  route(taskDescription) {
    const classification = this.classifyTask(taskDescription);
    this.routeCount++;

    const allocation = this.poolAllocation[classification.pool] || 0;

    const result = {
      routeId: `route-${this.routeCount}-${Date.now().toString(36)}`,
      classification,
      allocation,
      timestamp: new Date().toISOString(),
    };

    log.info('Task routed', {
      routeId: result.routeId,
      domain: classification.domain,
      pool: classification.pool,
      nodes: classification.nodes.join(', '),
    });

    return result;
  }

  /**
   * Get the current status of the conductor including routing table and pool metrics.
   * @returns {{ routingTable: object[], poolAllocation: object, routeCount: number, uptimeMs: number }}
   */
  getStatus() {
    return {
      routingTable: this.routingTable.map(({ domain, nodes, pool }) => ({ domain, nodes, pool })),
      poolAllocation: this.poolAllocation,
      routeCount: this.routeCount,
      uptimeMs: Date.now() - this.startTime,
    };
  }
}

/**
 * Create an Express application for the HeadyConductor service.
 * @param {object} [opts] - Options passed to HeadyConductor constructor.
 * @returns {import('express').Application} The configured Express app.
 */
export function createConductorService(opts = {}) {
  const conductor = new HeadyConductor(opts);
  const app = express();

  app.use(express.json());
  app.use(corsMiddleware);
  app.use(securityHeaders);
  app.use(correlationId);

  /**
   * POST /conductor/route
   * Classify and route a task description.
   * Body: { task: string }
   */
  app.post('/conductor/route', (req, res, next) => {
    try {
      const { task } = req.body;
      if (!task || typeof task !== 'string') {
        throw new ValidationError('Request body must include a "task" string');
      }
      const result = conductor.route(task);
      res.json(result);
    } catch (err) {
      next(err);
    }
  });

  /**
   * GET /conductor/status
   * Returns the routing table, pool allocation, and route count.
   */
  app.get('/conductor/status', (_req, res) => {
    res.json(conductor.getStatus());
  });

  app.get('/health', createHealthCheck({
    service: 'HeadyConductor',
    version: '4.0.0',
    checks: [
      {
        name: 'routing-table',
        check: async () => ({
          ok: conductor.routingTable.length > 0,
          detail: { domains: conductor.routingTable.length, routeCount: conductor.routeCount },
        }),
      },
      {
        name: 'pool-allocation',
        check: async () => ({
          ok: Object.keys(conductor.poolAllocation).length > 0,
          detail: { pools: Object.keys(conductor.poolAllocation) },
        }),
      },
    ],
  }));

  app.use(errorHandler);

  app._conductor = conductor;
  return app;
}
