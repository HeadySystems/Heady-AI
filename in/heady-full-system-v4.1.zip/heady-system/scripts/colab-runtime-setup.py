"""
Heady Colab Runtime 1 — Embedding Generation & Vector Operations
Run in Google Colab Pro+ with GPU (A100/T4).

Usage:
  1. Open in Colab
  2. Run all cells
  3. Copy the public tunnel URL
  4. Set COLAB_RUNTIME_1_URL in your .env
"""

# Cell 1: Install dependencies
# !pip install -q flask sentence-transformers torch cloudflared pyngrok

import os
import time
import json
import threading
import subprocess
import numpy as np
from datetime import datetime

PHI = 1.618033988749895
PSI = 1 / PHI
CSL_THRESHOLD_MEDIUM = 0.809

# Cell 2: Initialize embedding model
from sentence_transformers import SentenceTransformer

print("Loading embedding model (all-MiniLM-L6-v2)...")
model = SentenceTransformer('all-MiniLM-L6-v2')
EMBEDDING_DIM = 384
print(f"Model loaded. Embedding dimension: {EMBEDDING_DIM}")

# Cell 3: Flask service
from flask import Flask, request, jsonify

app = Flask(__name__)
start_time = time.time()
request_count = 0
coherence_history = []


@app.route('/health', methods=['GET'])
def health():
    """Health endpoint with coherence scoring."""
    uptime = time.time() - start_time
    return jsonify({
        'status': 'healthy',
        'service': 'heady-colab-runtime-1',
        'role': 'embedding-generation',
        'uptime_seconds': round(uptime, 2),
        'request_count': request_count,
        'embedding_dim': EMBEDDING_DIM,
        'model': 'all-MiniLM-L6-v2',
        'gpu_available': __import__('torch').cuda.is_available(),
        'timestamp': datetime.utcnow().isoformat() + 'Z',
    })


@app.route('/embed', methods=['POST'])
def embed():
    """Generate 384D embeddings from text."""
    global request_count
    request_count += 1

    data = request.get_json()
    if not data or 'text' not in data:
        return jsonify({'error': 'Request body must include "text" (string or array)'}), 400

    texts = data['text'] if isinstance(data['text'], list) else [data['text']]
    embeddings = model.encode(texts, normalize_embeddings=True)

    return jsonify({
        'embeddings': embeddings.tolist(),
        'dimension': EMBEDDING_DIM,
        'count': len(texts),
        'model': 'all-MiniLM-L6-v2',
    })


@app.route('/similarity', methods=['POST'])
def similarity():
    """Compute cosine similarity between two texts (CSL AND gate)."""
    global request_count
    request_count += 1

    data = request.get_json()
    if not data or 'text_a' not in data or 'text_b' not in data:
        return jsonify({'error': 'Request body must include "text_a" and "text_b"'}), 400

    embeddings = model.encode([data['text_a'], data['text_b']], normalize_embeddings=True)
    score = float(np.dot(embeddings[0], embeddings[1]))

    return jsonify({
        'similarity': score,
        'above_minimum': score > 0.500,
        'above_medium': score > CSL_THRESHOLD_MEDIUM,
        'text_a': data['text_a'][:80],
        'text_b': data['text_b'][:80],
    })


@app.route('/batch-embed', methods=['POST'])
def batch_embed():
    """Batch embedding for multiple texts."""
    global request_count
    request_count += 1

    data = request.get_json()
    if not data or 'texts' not in data:
        return jsonify({'error': 'Request body must include "texts" array'}), 400

    texts = data['texts']
    batch_size = int(data.get('batch_size', 34))  # Fibonacci: fib(9)
    all_embeddings = []

    for i in range(0, len(texts), batch_size):
        batch = texts[i:i + batch_size]
        embeddings = model.encode(batch, normalize_embeddings=True)
        all_embeddings.extend(embeddings.tolist())

    return jsonify({
        'embeddings': all_embeddings,
        'dimension': EMBEDDING_DIM,
        'count': len(texts),
        'batch_size': batch_size,
    })


# Cell 4: Heartbeat loop
def heartbeat_loop(interval_seconds=60):
    """Periodic coherence monitoring heartbeat."""
    while True:
        try:
            uptime = time.time() - start_time
            log_entry = {
                'timestamp': datetime.utcnow().isoformat() + 'Z',
                'service': 'heady-colab-runtime-1',
                'uptime_seconds': round(uptime, 2),
                'request_count': request_count,
                'gpu_memory_mb': round(
                    __import__('torch').cuda.memory_allocated() / 1024 / 1024, 2
                ) if __import__('torch').cuda.is_available() else 0,
            }
            print(json.dumps(log_entry))
        except Exception as e:
            print(json.dumps({'error': str(e), 'timestamp': datetime.utcnow().isoformat() + 'Z'}))
        time.sleep(interval_seconds)


heartbeat_thread = threading.Thread(target=heartbeat_loop, daemon=True)
heartbeat_thread.start()

# Cell 5: Expose via cloudflared tunnel
PORT = 5000
print(f"Starting Heady Colab Runtime 1 on port {PORT}...")

# Start cloudflared tunnel in background
tunnel_proc = subprocess.Popen(
    ['cloudflared', 'tunnel', '--url', f'http://localhost:{PORT}'],
    stdout=subprocess.PIPE,
    stderr=subprocess.PIPE,
)
time.sleep(3)

# Read tunnel URL from stderr
print("Tunnel starting... Watch for the public URL above.")
print("Set COLAB_RUNTIME_1_URL=<tunnel_url> in your .env file.")

app.run(host='0.0.0.0', port=PORT, debug=False)
