#!/usr/bin/env bash
set -euo pipefail

# Heady System — Cloud Run Deployment Script
# Usage: ./scripts/deploy.sh [--project PROJECT] [--region REGION]

PROJECT="${CLOUD_RUN_PROJECT:-gen-lang-client-0920560496}"
REGION="${CLOUD_RUN_REGION:-us-east1}"
SERVICE_NAME="heady-system"
IMAGE="gcr.io/${PROJECT}/${SERVICE_NAME}"
TAG="$(git rev-parse --short HEAD 2>/dev/null || echo 'latest')"

echo "╔════════════════════════════════════════════╗"
echo "║  Heady System — Deployment v4.0.0          ║"
echo "╚════════════════════════════════════════════╝"

# Parse arguments
while [[ $# -gt 0 ]]; do
  case $1 in
    --project) PROJECT="$2"; shift 2 ;;
    --region)  REGION="$2"; shift 2 ;;
    *)         echo "Unknown option: $1"; exit 1 ;;
  esac
done

echo "[1/5] Building Docker image..."
docker build -t "${IMAGE}:${TAG}" -t "${IMAGE}:latest" .

echo "[2/5] Pushing to Google Container Registry..."
docker push "${IMAGE}:${TAG}"
docker push "${IMAGE}:latest"

echo "[3/5] Deploying to Cloud Run..."
gcloud run deploy "${SERVICE_NAME}" \
  --image "${IMAGE}:${TAG}" \
  --project "${PROJECT}" \
  --region "${REGION}" \
  --platform managed \
  --allow-unauthenticated \
  --port 3000 \
  --memory 512Mi \
  --cpu 1 \
  --min-instances 1 \
  --max-instances 8 \
  --set-env-vars "NODE_ENV=production"

echo "[4/5] Retrieving service URL..."
SERVICE_URL=$(gcloud run services describe "${SERVICE_NAME}" \
  --project "${PROJECT}" \
  --region "${REGION}" \
  --format 'value(status.url)')

echo "[5/5] Verifying health endpoints..."
HEALTH_STATUS=$(curl -s -o /dev/null -w "%{http_code}" "${SERVICE_URL}/health" || echo "000")

if [ "$HEALTH_STATUS" = "200" ]; then
  echo ""
  echo "╔════════════════════════════════════════════╗"
  echo "║  Deployment Successful                     ║"
  echo "╠════════════════════════════════════════════╣"
  echo "║  Service:    ${SERVICE_NAME}"
  echo "║  Image:      ${IMAGE}:${TAG}"
  echo "║  URL:        ${SERVICE_URL}"
  echo "║  Conductor:  ${SERVICE_URL}/conductor/status"
  echo "║  Brains:     ${SERVICE_URL}/brains/status"
  echo "║  Memory:     ${SERVICE_URL}/memory/coherence"
  echo "║  Health:     ${SERVICE_URL}/health"
  echo "╚════════════════════════════════════════════╝"
else
  echo "WARNING: Health check returned ${HEALTH_STATUS}"
  echo "Service URL: ${SERVICE_URL}"
  echo "Check logs: gcloud run services logs read ${SERVICE_NAME} --project ${PROJECT} --region ${REGION}"
fi
