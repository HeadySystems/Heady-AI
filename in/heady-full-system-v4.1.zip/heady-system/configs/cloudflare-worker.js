/**
 * Heady Edge Gateway — Cloudflare Worker
 * Routes requests to Cloud Run services and Colab runtimes.
 * Deploy: wrangler publish
 */

const CLOUD_RUN_URL = 'CLOUD_RUN_URL'; // Set via wrangler secret
const COLAB_RUNTIME_1 = 'COLAB_RUNTIME_1_URL';
const COLAB_RUNTIME_2 = 'COLAB_RUNTIME_2_URL';
const COLAB_RUNTIME_3 = 'COLAB_RUNTIME_3_URL';

const ALLOWED_ORIGINS = [
  'https://headysystems.com',
  'https://headyme.com',
  'https://headyconnection.org',
  'https://headybuddy.org',
  'https://headymcp.com',
  'https://headyio.com',
  'https://headybot.com',
  'https://headyapi.com',
  'https://headyai.com',
];

const ROUTE_MAP = [
  { prefix: '/conductor', target: 'cloud_run', port: 3000 },
  { prefix: '/brains', target: 'cloud_run', port: 3001 },
  { prefix: '/memory', target: 'cloud_run', port: 3002 },
  { prefix: '/embed', target: 'colab_1' },
  { prefix: '/similarity', target: 'colab_1' },
  { prefix: '/generate', target: 'colab_2' },
  { prefix: '/classify', target: 'colab_2' },
  { prefix: '/simulate', target: 'colab_3' },
  { prefix: '/coherence-analysis', target: 'colab_3' },
];

/**
 * Add security and CORS headers to response.
 * @param {Response} response - The upstream response.
 * @param {string} origin - The request origin.
 * @returns {Response} Response with headers added.
 */
function addHeaders(response, origin) {
  const headers = new Headers(response.headers);

  if (ALLOWED_ORIGINS.includes(origin)) {
    headers.set('Access-Control-Allow-Origin', origin);
  }
  headers.set('Access-Control-Allow-Methods', 'GET,POST,PUT,DELETE,OPTIONS');
  headers.set('Access-Control-Allow-Headers', 'Content-Type,Authorization,X-Correlation-ID');
  headers.set('Access-Control-Allow-Credentials', 'true');
  headers.set('Access-Control-Max-Age', '600');

  headers.set('X-Content-Type-Options', 'nosniff');
  headers.set('X-Frame-Options', 'DENY');
  headers.set('Referrer-Policy', 'strict-origin-when-cross-origin');

  return new Response(response.body, {
    status: response.status,
    statusText: response.statusText,
    headers,
  });
}

/**
 * Resolve target URL from route map.
 * @param {string} pathname - The request path.
 * @param {object} env - Worker environment bindings.
 * @returns {{ url: string, matched: boolean }}
 */
function resolveTarget(pathname, env) {
  for (const route of ROUTE_MAP) {
    if (pathname.startsWith(route.prefix)) {
      let baseUrl;
      switch (route.target) {
        case 'cloud_run':
          baseUrl = env.CLOUD_RUN_URL || CLOUD_RUN_URL;
          break;
        case 'colab_1':
          baseUrl = env.COLAB_RUNTIME_1_URL || COLAB_RUNTIME_1;
          break;
        case 'colab_2':
          baseUrl = env.COLAB_RUNTIME_2_URL || COLAB_RUNTIME_2;
          break;
        case 'colab_3':
          baseUrl = env.COLAB_RUNTIME_3_URL || COLAB_RUNTIME_3;
          break;
        default:
          continue;
      }
      return { url: `${baseUrl}${pathname}`, matched: true };
    }
  }
  return { url: '', matched: false };
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const origin = request.headers.get('Origin') || '';

    // Handle CORS preflight
    if (request.method === 'OPTIONS') {
      return addHeaders(new Response(null, { status: 204 }), origin);
    }

    // Health check for the worker itself
    if (url.pathname === '/health' || url.pathname === '/') {
      return addHeaders(
        new Response(JSON.stringify({
          status: 'healthy',
          service: 'heady-edge-gateway',
          routes: ROUTE_MAP.length,
          timestamp: new Date().toISOString(),
        }), { headers: { 'Content-Type': 'application/json' } }),
        origin,
      );
    }

    // Route to target
    const { url: targetUrl, matched } = resolveTarget(url.pathname, env);

    if (!matched) {
      return addHeaders(
        new Response(JSON.stringify({
          error: 'NOT_FOUND',
          message: `No route matched for ${url.pathname}`,
          available_routes: ROUTE_MAP.map((r) => r.prefix),
        }), { status: 404, headers: { 'Content-Type': 'application/json' } }),
        origin,
      );
    }

    try {
      const proxyRequest = new Request(targetUrl, {
        method: request.method,
        headers: request.headers,
        body: request.method !== 'GET' && request.method !== 'HEAD' ? request.body : null,
      });

      const response = await fetch(proxyRequest);
      return addHeaders(response, origin);
    } catch (err) {
      return addHeaders(
        new Response(JSON.stringify({
          error: 'UPSTREAM_ERROR',
          message: err.message,
          target: targetUrl,
        }), { status: 502, headers: { 'Content-Type': 'application/json' } }),
        origin,
      );
    }
  },
};
