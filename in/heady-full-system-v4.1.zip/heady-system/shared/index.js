/**
 * @module @heady/system
 * @description Re-exports all shared foundation modules.
 */

export {
  PHI,
  PSI,
  PHI2,
  PHI3,
  FIB,
  fib,
  CSL_THRESHOLDS,
  DEDUP_THRESHOLD,
  COHERENCE_DRIFT_THRESHOLD,
  PRESSURE_LEVELS,
  ALERT_THRESHOLDS,
  phiFusionWeights,
  phiPriorityScore,
  EVICTION_WEIGHTS,
  RESOURCE_WEIGHTS,
  phiResourceWeights,
  phiBackoff,
  fibRetryBackoff,
  phiAdaptiveInterval,
  phiThreshold,
  phiTokenBudgets,
  COMPRESSION_TRIGGER,
  PHI_TEMPERATURE,
  cslGate,
  cslBlend,
  adaptiveTemperature,
  cosineSimilarity,
  cslAND,
  cslOR,
  cslNOT,
  cslIMPLY,
  cslCONSENSUS,
  cslXOR,
  SIZING,
  POOL_SIZES,
  RELEVANCE_GATES,
  phiMultiSplit,
} from './phi-math.js';

export {
  dotProduct,
  magnitude,
  normalize,
  cslGATE,
} from './csl-engine.js';

export { createLogger, als } from './logger.js';

export { createHealthCheck } from './health.js';

export { validateConfig } from './config.js';

export {
  AppError,
  NotFoundError,
  ValidationError,
  AuthError,
  RateLimitError,
  CoherenceDriftError,
} from './errors.js';

export {
  corsMiddleware,
  securityHeaders,
  rateLimiter,
  correlationId,
  errorHandler,
} from './middleware.js';

export { createCircuitBreaker, STATES } from './circuit-breaker.js';
