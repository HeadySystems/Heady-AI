/**
 * @module circuit-breaker
 * @description Circuit breaker with phi-based exponential backoff.
 * States: CLOSED (normal), OPEN (failing), HALF_OPEN (probing).
 */

import { FIB, phiBackoff } from './phi-math.js';
import { createLogger } from './logger.js';

const log = createLogger('circuit-breaker');

/** Circuit breaker states. */
export const STATES = Object.freeze({
  CLOSED: 'CLOSED',
  OPEN: 'OPEN',
  HALF_OPEN: 'HALF_OPEN',
});

/**
 * @typedef {Object} CircuitBreakerConfig
 * @property {string} name - Name of the circuit (for logging).
 * @property {number} [threshold] - Failure count to trip. Default: FIB[5] = 5.
 * @property {(attempt: number) => number} [resetTimeout] - Backoff function. Default: phiBackoff.
 * @property {number} [halfOpenMax] - Max concurrent probes in HALF_OPEN. Default: FIB[3] = 2.
 */

/**
 * Create a circuit breaker instance.
 *
 * @param {CircuitBreakerConfig} config
 * @returns {{
 *   execute: <T>(fn: () => Promise<T>) => Promise<T>,
 *   getState: () => string,
 *   getStats: () => {state: string, failures: number, successes: number, lastFailure: number|null},
 *   reset: () => void,
 * }}
 *
 * @example
 * const breaker = createCircuitBreaker({ name: 'db' });
 * const result = await breaker.execute(() => db.query('SELECT 1'));
 */
export function createCircuitBreaker(config) {
  const {
    name,
    threshold = FIB[5],          // 5
    resetTimeout = phiBackoff,
    halfOpenMax = FIB[3],         // 2
  } = config;

  let state = STATES.CLOSED;
  let failures = 0;
  let successes = 0;
  let consecutiveFailures = 0;
  let lastFailureTime = null;
  let openedAt = null;
  let halfOpenAttempts = 0;

  /**
   * Determine the current reset timeout based on consecutive failure rounds.
   * @returns {number} Timeout in milliseconds.
   */
  function currentResetTimeout() {
    return resetTimeout(consecutiveFailures);
  }

  /**
   * Transition to a new state.
   * @param {string} newState
   */
  function transitionTo(newState) {
    if (state !== newState) {
      log.info({ circuit: name, from: state, to: newState }, `Circuit ${name}: ${state} -> ${newState}`);
      state = newState;
    }
  }

  /**
   * Record a successful call.
   */
  function onSuccess() {
    successes++;
    if (state === STATES.HALF_OPEN) {
      // Success in half-open resets to closed
      failures = 0;
      consecutiveFailures = 0;
      halfOpenAttempts = 0;
      transitionTo(STATES.CLOSED);
    } else if (state === STATES.CLOSED) {
      // Successful call in closed state resets failure count
      failures = 0;
    }
  }

  /**
   * Record a failed call.
   */
  function onFailure() {
    failures++;
    lastFailureTime = Date.now();

    if (state === STATES.HALF_OPEN) {
      // Any failure in half-open immediately re-opens
      consecutiveFailures++;
      halfOpenAttempts = 0;
      openedAt = Date.now();
      transitionTo(STATES.OPEN);
    } else if (state === STATES.CLOSED && failures >= threshold) {
      consecutiveFailures++;
      openedAt = Date.now();
      transitionTo(STATES.OPEN);
    }
  }

  /**
   * Check if the circuit should transition from OPEN to HALF_OPEN.
   * @returns {boolean}
   */
  function shouldAttemptReset() {
    if (state !== STATES.OPEN) return false;
    const elapsed = Date.now() - openedAt;
    return elapsed >= currentResetTimeout();
  }

  return {
    /**
     * Execute a function through the circuit breaker.
     * @template T
     * @param {() => Promise<T>} fn - Async function to execute.
     * @returns {Promise<T>} Result of fn.
     * @throws {Error} If circuit is open.
     */
    async execute(fn) {
      if (state === STATES.OPEN) {
        if (shouldAttemptReset()) {
          transitionTo(STATES.HALF_OPEN);
          halfOpenAttempts = 0;
        } else {
          const err = new Error(`Circuit ${name} is OPEN`);
          err.code = 'CIRCUIT_OPEN';
          throw err;
        }
      }

      if (state === STATES.HALF_OPEN && halfOpenAttempts >= halfOpenMax) {
        const err = new Error(`Circuit ${name} is HALF_OPEN: max probes reached`);
        err.code = 'CIRCUIT_HALF_OPEN';
        throw err;
      }

      if (state === STATES.HALF_OPEN) {
        halfOpenAttempts++;
      }

      try {
        const result = await fn();
        onSuccess();
        return result;
      } catch (err) {
        onFailure();
        throw err;
      }
    },

    /**
     * Get the current circuit state.
     * @returns {string}
     */
    getState() {
      // Check for auto-transition to half-open
      if (state === STATES.OPEN && shouldAttemptReset()) {
        transitionTo(STATES.HALF_OPEN);
        halfOpenAttempts = 0;
      }
      return state;
    },

    /**
     * Get circuit statistics.
     * @returns {{state: string, failures: number, successes: number, lastFailure: number|null}}
     */
    getStats() {
      return {
        state,
        failures,
        successes,
        lastFailure: lastFailureTime,
      };
    },

    /**
     * Manually reset the circuit to CLOSED.
     */
    reset() {
      failures = 0;
      consecutiveFailures = 0;
      halfOpenAttempts = 0;
      transitionTo(STATES.CLOSED);
    },
  };
}
