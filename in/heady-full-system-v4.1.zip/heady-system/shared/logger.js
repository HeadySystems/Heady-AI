/**
 * @module logger
 * @description Structured JSON logger using process.stdout.write.
 * Supports correlation ID propagation via AsyncLocalStorage.
 */

import { AsyncLocalStorage } from 'node:async_hooks';
import { randomUUID } from 'node:crypto';

/**
 * AsyncLocalStorage instance for correlation ID propagation.
 * Services should run request handlers inside als.run({ correlationId }) to enable tracing.
 * @type {AsyncLocalStorage<{correlationId: string}>}
 */
export const als = new AsyncLocalStorage();

/**
 * Get the current correlation ID from AsyncLocalStorage, or generate a new one.
 * @returns {string} Correlation ID (UUID v4).
 */
function getCorrelationId() {
  const store = als.getStore();
  return store?.correlationId || randomUUID();
}

/**
 * Write a structured log entry to stdout.
 * @param {string} level - Log level (info, warn, error, debug).
 * @param {string} service - Service name.
 * @param {object|null} data - Arbitrary structured data.
 * @param {string} message - Human-readable message.
 */
function writeLog(level, service, data, message) {
  const entry = {
    timestamp: new Date().toISOString(),
    level,
    service,
    correlationId: getCorrelationId(),
    message,
    ...(data != null && typeof data === 'object' ? data : {}),
  };
  process.stdout.write(JSON.stringify(entry) + '\n');
}

/**
 * Create a structured logger bound to a service name.
 * @param {string} serviceName - Name of the service for log attribution.
 * @returns {{info: Function, warn: Function, error: Function, debug: Function}}
 */
export function createLogger(serviceName) {
  return {
    /**
     * Log at INFO level.
     * @param {object|null} data - Structured data to include.
     * @param {string} message - Log message.
     */
    info(data, message) {
      writeLog('info', serviceName, data, message);
    },

    /**
     * Log at WARN level.
     * @param {object|null} data - Structured data to include.
     * @param {string} message - Log message.
     */
    warn(data, message) {
      writeLog('warn', serviceName, data, message);
    },

    /**
     * Log at ERROR level.
     * @param {object|null} data - Structured data to include.
     * @param {string} message - Log message.
     */
    error(data, message) {
      writeLog('error', serviceName, data, message);
    },

    /**
     * Log at DEBUG level.
     * @param {object|null} data - Structured data to include.
     * @param {string} message - Log message.
     */
    debug(data, message) {
      writeLog('debug', serviceName, data, message);
    },
  };
}
