/**
 * Heady Phi-Math Foundation — Canonical Reference Implementation
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder — 60+ Provisional Patents
 * @version 4.1.0
 *
 * All constants, thresholds, and allocation functions derive from the golden ratio.
 * This module is the single source of truth for phi-math and CSL gate operations.
 */

// ═══════════════════════════════════════════════════════════════════════════════
// CORE CONSTANTS
// ═══════════════════════════════════════════════════════════════════════════════

/** Golden ratio φ = (1 + √5) / 2 */
export const PHI = (1 + Math.sqrt(5)) / 2;

/** Conjugate ψ = 1 / φ = φ - 1 */
export const PSI = 1 / PHI;

/** φ² = φ + 1 */
export const PHI2 = PHI + 1;

/** φ³ = 2φ + 1 */
export const PHI3 = 2 * PHI + 1;

/**
 * First 21 Fibonacci numbers (0-indexed: F(0)=0, F(1)=1, ..., F(20)=6765)
 * @type {readonly number[]}
 */
export const FIB = Object.freeze((() => {
  const seq = [0, 1];
  for (let i = 2; i <= 20; i++) {
    seq.push(seq[i - 1] + seq[i - 2]);
  }
  return seq;
})());

/**
 * Compute Fibonacci number for any n (extends beyond FIB array).
 * @param {number} n - Index (0-based).
 * @returns {number} F(n)
 */
export function fib(n) {
  if (n < 0) return 0;
  if (n < FIB.length) return FIB[n];
  let a = FIB[FIB.length - 2];
  let b = FIB[FIB.length - 1];
  for (let i = FIB.length; i <= n; i++) {
    const c = a + b;
    a = b;
    b = c;
  }
  return b;
}

// ═══════════════════════════════════════════════════════════════════════════════
// CSL THRESHOLDS
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Compute the CSL threshold for a numeric level.
 * level 0 → 0.5 (MINIMUM), level 4 → ~0.927 (CRITICAL).
 * Formula: 1 - spread × ψ^level
 * @param {number} level - Numeric level (0+).
 * @param {number} [spread=0.5] - Spread factor.
 * @returns {number} Threshold value in [0, 1).
 */
export function phiThreshold(level, spread = 0.5) {
  return 1 - spread * Math.pow(PSI, level);
}

/**
 * Coherence Similarity Level thresholds, computed from phiThreshold.
 * @type {Readonly<{MINIMUM: number, LOW: number, MEDIUM: number, HIGH: number, CRITICAL: number}>}
 */
export const CSL_THRESHOLDS = Object.freeze({
  MINIMUM:  phiThreshold(0),
  LOW:      phiThreshold(1),
  MEDIUM:   phiThreshold(2),
  HIGH:     phiThreshold(3),
  CRITICAL: phiThreshold(4),
});

/**
 * Deduplication threshold — vectors above this cosine similarity are considered duplicates.
 * @type {number}
 */
export const DEDUP_THRESHOLD = 1 - Math.pow(PSI, 6) * 0.5;

/**
 * Coherence drift threshold — below this triggers drift alerts.
 * @type {number}
 */
export const COHERENCE_DRIFT_THRESHOLD = CSL_THRESHOLDS.MEDIUM;

// ═══════════════════════════════════════════════════════════════════════════════
// PRESSURE & ALERTS
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Pressure levels with {min, max} ranges.
 * @type {Readonly<{NOMINAL: {min: number, max: number}, ELEVATED: {min: number, max: number}, HIGH: {min: number, max: number}, CRITICAL: {min: number, max: number}}>}
 */
export const PRESSURE_LEVELS = Object.freeze({
  NOMINAL:  Object.freeze({ min: 0, max: Math.pow(PSI, 2) }),
  ELEVATED: Object.freeze({ min: Math.pow(PSI, 2), max: PSI }),
  HIGH:     Object.freeze({ min: PSI, max: 1 - Math.pow(PSI, 3) }),
  CRITICAL: Object.freeze({ min: 1 - Math.pow(PSI, 4), max: 1.0 }),
});

/**
 * Alert thresholds derived from phi.
 * @type {Readonly<{warning: number, caution: number, critical: number, exceeded: number, hard_max: number}>}
 */
export const ALERT_THRESHOLDS = Object.freeze({
  warning:  PSI,                     // ≈ 0.618
  caution:  1 - Math.pow(PSI, 2),    // ≈ 0.618
  critical: 1 - Math.pow(PSI, 3),    // ≈ 0.764
  exceeded: 1 - Math.pow(PSI, 4),    // ≈ 0.854
  hard_max: 1.0,
});

// ═══════════════════════════════════════════════════════════════════════════════
// FUSION & SCORING
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Generate n fusion weights that sum to 1, distributed by descending powers of ψ.
 * Weight_i = ψ^i / Σ(ψ^j) for j in [0, n).
 * @param {number} n - Number of weights.
 * @returns {number[]} Array of n weights summing to 1.
 */
export function phiFusionWeights(n) {
  if (n <= 0) return [];
  const raw = [];
  let sum = 0;
  for (let i = 0; i < n; i++) {
    const w = Math.pow(PSI, i);
    raw.push(w);
    sum += w;
  }
  return raw.map((w) => w / sum);
}

/**
 * Compute a priority score from variable number of factors.
 * Uses phi-weighted geometric mean.
 * @param {...number} factors - Factor values (0-1 range recommended).
 * @returns {number} Priority score.
 */
export function phiPriorityScore(...factors) {
  if (factors.length === 0) return 0;
  const weights = phiFusionWeights(factors.length);
  let score = 0;
  for (let i = 0; i < factors.length; i++) {
    score += weights[i] * factors[i];
  }
  return score;
}

/**
 * Eviction weights for cache management.
 * @type {Readonly<{importance: number, recency: number, relevance: number}>}
 */
export const EVICTION_WEIGHTS = Object.freeze((() => {
  const w = phiFusionWeights(3);
  return { importance: w[0], recency: w[1], relevance: w[2] };
})());

/**
 * Resource allocation weights for pool management.
 * @type {Readonly<{hot: number, warm: number, cold: number, reserve: number, governance: number}>}
 */
export const RESOURCE_WEIGHTS = Object.freeze((() => {
  const w = phiFusionWeights(5);
  return { hot: w[0], warm: w[1], cold: w[2], reserve: w[3], governance: w[4] };
})());

/**
 * Generate n resource weights using phi-harmonic distribution.
 * @param {number} n - Number of resource slots.
 * @returns {number[]} Array of n weights summing to 1.
 */
export function phiResourceWeights(n) {
  return phiFusionWeights(n);
}

// ═══════════════════════════════════════════════════════════════════════════════
// BACKOFF & TIMING
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Phi-derived exponential backoff.
 * delay = min(baseMs × φ^attempt, maxMs), optionally with jitter.
 * @param {number} attempt - Zero-based attempt index.
 * @param {number} [baseMs=1000] - Base delay in milliseconds.
 * @param {number} [maxMs=60000] - Maximum delay cap in milliseconds.
 * @param {boolean} [jitter=true] - Whether to add random jitter (±ψ² ≈ ±38.2%).
 * @returns {number} Delay in milliseconds (integer).
 */
export function phiBackoff(attempt, baseMs = 1000, maxMs = 60000, jitter = true) {
  const delay = Math.min(baseMs * Math.pow(PHI, attempt), maxMs);
  if (!jitter) return Math.round(delay);
  const jitterRange = Math.pow(PSI, 2);
  const factor = 1 + (Math.random() * 2 - 1) * jitterRange;
  return Math.round(delay * factor);
}

/**
 * Fibonacci-based retry backoff schedule.
 * Returns an array of delay values based on Fibonacci numbers.
 * @param {number} [count=5] - Number of retry delays.
 * @param {number} [multiplier=100] - Multiplier in ms.
 * @returns {number[]} Array of delay values in ms.
 */
export function fibRetryBackoff(count = 5, multiplier = 100) {
  return FIB.slice(4, 4 + count).map((n) => n * multiplier);
}

/**
 * Adaptive interval that adjusts based on health status.
 * Healthy → converge toward baseMs; unhealthy → back off from currentMs.
 * @param {number} baseMs - Target interval.
 * @param {boolean} healthy - Whether the system is healthy.
 * @param {number} currentMs - Current interval value.
 * @returns {number} New interval in ms.
 */
export function phiAdaptiveInterval(baseMs, healthy, currentMs) {
  if (healthy) return Math.min(currentMs * PHI, baseMs * PHI3);
  return Math.max(currentMs * PSI, baseMs * PSI);
}

// ═══════════════════════════════════════════════════════════════════════════════
// TOKEN BUDGETS
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Split a token budget into phi-proportioned tiers.
 * @param {number} [base=8192] - Base token budget.
 * @returns {{working: number, session: number, memory: number, artifacts: number}}
 */
export function phiTokenBudgets(base = 8192) {
  const working   = base;
  const session   = Math.round(base * PHI2);
  const memory    = Math.round(base * PHI2 * PHI2);
  const artifacts = Math.round(base * Math.pow(PHI, 6));
  return { working, session, memory, artifacts };
}

/** Compression trigger threshold. */
export const COMPRESSION_TRIGGER = 1 - Math.pow(PSI, 4);

/** PHI temperature for CSL gating. */
export const PHI_TEMPERATURE = Math.pow(PSI, 3);

// ═══════════════════════════════════════════════════════════════════════════════
// CSL GATES
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * CSL GATE — sigmoid-style gating function.
 * gate = σ((cosScore - tau) / temp); returns value × gate.
 * @param {number} value - The value to gate.
 * @param {number} cosScore - Cosine similarity score.
 * @param {number} tau - Threshold center.
 * @param {number} [temp=PHI_TEMPERATURE] - Temperature controlling sharpness.
 * @returns {number} Gated value.
 */
export function cslGate(value, cosScore, tau, temp = PHI_TEMPERATURE) {
  const gate = 1 / (1 + Math.exp(-(cosScore - tau) / temp));
  return value * gate;
}

/**
 * CSL Blend — weighted interpolation gated by cosine score.
 * result = weightLow + (weightHigh - weightLow) × sigmoid
 * @param {number} weightHigh - Value when coherence is high.
 * @param {number} weightLow - Value when coherence is low.
 * @param {number} cosScore - Cosine similarity score.
 * @param {number} tau - Threshold center.
 * @returns {number} Blended value.
 */
export function cslBlend(weightHigh, weightLow, cosScore, tau) {
  const sigmoid = 1 / (1 + Math.exp(-(cosScore - tau) / PHI_TEMPERATURE));
  return weightLow + (weightHigh - weightLow) * sigmoid;
}

/**
 * Adaptive temperature based on entropy.
 * @param {number} entropy - Current entropy.
 * @param {number} maxEntropy - Maximum entropy.
 * @returns {number} Adjusted temperature.
 */
export function adaptiveTemperature(entropy, maxEntropy) {
  const ratio = entropy / maxEntropy;
  return PHI_TEMPERATURE * (1 + ratio * PHI);
}

/**
 * Cosine similarity between two vectors (loop-based implementation).
 * @param {number[]} a - First vector.
 * @param {number[]} b - Second vector.
 * @returns {number} Cosine similarity in [-1, 1].
 */
export function cosineSimilarity(a, b) {
  let dot = 0, magA = 0, magB = 0;
  for (let i = 0; i < a.length; i++) {
    dot += a[i] * b[i];
    magA += a[i] * a[i];
    magB += b[i] * b[i];
  }
  magA = Math.sqrt(magA);
  magB = Math.sqrt(magB);
  if (magA === 0 || magB === 0) return 0;
  return dot / (magA * magB);
}

/**
 * CSL AND — cosine similarity gate.
 * @param {number[]} a - First vector.
 * @param {number[]} b - Second vector.
 * @returns {number} Cosine similarity score.
 */
export function cslAND(a, b) {
  return cosineSimilarity(a, b);
}

/**
 * CSL OR — normalized superposition.
 * @param {number[]} a - First vector.
 * @param {number[]} b - Second vector.
 * @returns {number[]} Normalized superposition vector.
 */
export function cslOR(a, b) {
  const combined = [];
  for (let i = 0; i < a.length; i++) {
    combined.push(a[i] + b[i]);
  }
  let mag = 0;
  for (let i = 0; i < combined.length; i++) {
    mag += combined[i] * combined[i];
  }
  mag = Math.sqrt(mag);
  if (mag === 0) return combined;
  return combined.map((v) => v / mag);
}

/**
 * CSL NOT — orthogonal projection (rejection).
 * @param {number[]} a - Vector to project.
 * @param {number[]} b - Vector to project away from.
 * @returns {number[]} Orthogonal component of `a` with respect to `b`.
 */
export function cslNOT(a, b) {
  let dotAB = 0, dotBB = 0;
  for (let i = 0; i < a.length; i++) {
    dotAB += a[i] * b[i];
    dotBB += b[i] * b[i];
  }
  if (dotBB === 0) return [...a];
  const scale = dotAB / dotBB;
  return a.map((val, i) => val - scale * b[i]);
}

/**
 * CSL IMPLY — vector projection.
 * @param {number[]} a - Vector to project.
 * @param {number[]} b - Direction to project onto.
 * @returns {number[]} Projection of `a` onto `b`.
 */
export function cslIMPLY(a, b) {
  let dotAB = 0, dotBB = 0;
  for (let i = 0; i < a.length; i++) {
    dotAB += a[i] * b[i];
    dotBB += b[i] * b[i];
  }
  if (dotBB === 0) return new Array(a.length).fill(0);
  const scale = dotAB / dotBB;
  return b.map((val) => scale * val);
}

/**
 * CSL CONSENSUS — weighted centroid of multiple vectors.
 * Default weights use phiFusionWeights.
 * @param {number[][]} vectors - Array of vectors.
 * @param {number[]} [weights] - Optional weights. Defaults to phiFusionWeights.
 * @returns {number[]} Normalized consensus vector.
 */
export function cslCONSENSUS(vectors, weights) {
  if (vectors.length === 0) return [];
  const dim = vectors[0].length;
  const w = weights || phiFusionWeights(vectors.length);
  const wSum = w.reduce((a, b) => a + b, 0);

  const centroid = new Array(dim).fill(0);
  for (let v = 0; v < vectors.length; v++) {
    const wNorm = w[v] / wSum;
    for (let d = 0; d < dim; d++) {
      centroid[d] += vectors[v][d] * wNorm;
    }
  }
  // normalize
  let mag = 0;
  for (let i = 0; i < dim; i++) {
    mag += centroid[i] * centroid[i];
  }
  mag = Math.sqrt(mag);
  if (mag === 0) return centroid;
  return centroid.map((v) => v / mag);
}

/**
 * CSL XOR — symmetric difference (dissimilarity vector).
 * Returns the component of (a+b) orthogonal to (a∩b direction).
 * @param {number[]} a - First vector.
 * @param {number[]} b - Second vector.
 * @returns {number[]} XOR result vector.
 */
export function cslXOR(a, b) {
  const orVec = cslOR(a, b);
  const andScore = cslAND(a, b);
  const andProj = cslIMPLY(orVec, a).map((v) => v * andScore);
  return cslNOT(orVec, andProj);
}

// ═══════════════════════════════════════════════════════════════════════════════
// SIZING
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Fibonacci-keyed sizing constants.
 * @type {Readonly<Object>}
 */
export const SIZING = Object.freeze({
  FAILURE_THRESHOLD:  fib(5),   // 5
  BATCH_EVICTION:     fib(6),   // 8
  MAX_CONCURRENT:     fib(6),   // 8
  SMALL_LIMIT:        fib(7),   // 13
  HNSW_M:             fib(8),   // 21
  RERANK_TOP_K:       fib(8),   // 21
  SLIDING_WINDOW:     fib(9),   // 34
  MAX_ENTITIES:       fib(10),  // 55
  RETENTION_DAYS:     fib(11),  // 89
  EF_SEARCH:          fib(11),  // 89
  EF_CONSTRUCTION:    fib(12),  // 144
  QUEUE_DEPTH:        fib(13),  // 233
  PATTERN_STORE:      fib(14),  // 377
  CACHE_SIZE:         fib(16),  // 987
  HISTORY_BUFFER:     fib(17),  // 1597
  LARGE_CACHE:        fib(20),  // 6765
});

/**
 * Pool size bounds.
 * @type {Readonly<{min: number, max: number}>}
 */
export const POOL_SIZES = Object.freeze({
  min: fib(3),   // 2
  max: fib(7),   // 13
});

/**
 * Relevance gates for content filtering.
 * @type {Readonly<{include: number, boost: number, inject: number}>}
 */
export const RELEVANCE_GATES = Object.freeze({
  include: Math.pow(PSI, 2),
  boost:   PSI,
  inject:  PSI + 0.1,
});

// ═══════════════════════════════════════════════════════════════════════════════
// BACKWARD COMPATIBILITY
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Split a whole amount into n parts using phi-proportioned ratios.
 * Kept for backward compatibility.
 * @param {number} whole - Total amount to split.
 * @param {number} n - Number of parts.
 * @returns {number[]} Array of n integer parts summing to whole.
 */
export function phiMultiSplit(whole, n) {
  if (n <= 0) return [];
  if (n === 1) return [whole];
  const weights = phiFusionWeights(n);
  const parts = weights.map((w) => Math.floor(w * whole));
  let remainder = whole - parts.reduce((a, b) => a + b, 0);
  for (let i = 0; i < parts.length && remainder > 0; i++) {
    parts[i]++;
    remainder--;
  }
  return parts;
}
