/**
 * @module middleware
 * @description Express middleware for the Heady system.
 * CORS, security headers, rate limiting, correlation IDs, and error handling.
 */

import { randomUUID } from 'node:crypto';
import { FIB } from './phi-math.js';
import { AppError } from './errors.js';
import { createLogger, als } from './logger.js';

const log = createLogger('middleware');

/**
 * CORS middleware.
 * Reads allowed origins from the ALLOWED_ORIGINS environment variable (comma-separated).
 * If ALLOWED_ORIGINS is not set, allows all origins (*).
 * @param {import('http').IncomingMessage} req
 * @param {import('http').ServerResponse} res
 * @param {Function} next
 */
export function corsMiddleware(req, res, next) {
  const allowedRaw = process.env.ALLOWED_ORIGINS;
  const origin = req.headers.origin;

  if (!allowedRaw || allowedRaw === '*') {
    res.setHeader('Access-Control-Allow-Origin', '*');
  } else {
    const allowed = allowedRaw.split(',').map((s) => s.trim());
    if (origin && allowed.includes(origin)) {
      res.setHeader('Access-Control-Allow-Origin', origin);
      res.setHeader('Vary', 'Origin');
    }
  }

  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, PATCH, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-Correlation-ID');
  res.setHeader('Access-Control-Max-Age', '86400');

  if (req.method === 'OPTIONS') {
    res.writeHead(204);
    res.end();
    return;
  }

  next();
}

/**
 * Security headers middleware.
 * Sets CSP, X-Content-Type-Options, X-Frame-Options, Referrer-Policy, Permissions-Policy.
 * @param {import('http').IncomingMessage} _req
 * @param {import('http').ServerResponse} res
 * @param {Function} next
 */
export function securityHeaders(_req, res, next) {
  res.setHeader('Content-Security-Policy', "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; font-src 'self'; connect-src 'self'; frame-ancestors 'none'");
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=(), interest-cohort=()');
  next();
}

/**
 * In-memory sliding window rate limiter.
 * Tracks requests per IP within a 60-second window.
 *
 * @param {number} [maxPerMinute] - Maximum requests per minute per IP. Defaults to FIB[11] = 89.
 * @returns {Function} Express middleware.
 */
export function rateLimiter(maxPerMinute) {
  const limit = maxPerMinute ?? FIB[11]; // 89
  /** @type {Map<string, number[]>} IP -> array of request timestamps */
  const windows = new Map();
  const WINDOW_MS = 60_000;

  // Periodic cleanup every 5 minutes to prevent unbounded memory growth
  const cleanupInterval = setInterval(() => {
    const now = Date.now();
    for (const [ip, timestamps] of windows) {
      const valid = timestamps.filter((t) => now - t < WINDOW_MS);
      if (valid.length === 0) {
        windows.delete(ip);
      } else {
        windows.set(ip, valid);
      }
    }
  }, 300_000);
  if (cleanupInterval.unref) cleanupInterval.unref();

  return (req, res, next) => {
    const ip = req.ip || req.socket?.remoteAddress || 'unknown';
    const now = Date.now();
    const timestamps = windows.get(ip) || [];

    // Remove timestamps outside the window
    const valid = timestamps.filter((t) => now - t < WINDOW_MS);
    valid.push(now);
    windows.set(ip, valid);

    const remaining = Math.max(0, limit - valid.length);
    res.setHeader('X-RateLimit-Limit', String(limit));
    res.setHeader('X-RateLimit-Remaining', String(remaining));

    if (valid.length > limit) {
      res.setHeader('Retry-After', '60');
      res.writeHead(429, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'Rate Limit Exceeded', code: 'RATE_LIMIT' }));
      return;
    }

    next();
  };
}

/**
 * Correlation ID middleware.
 * Reads X-Correlation-ID from the incoming request or generates a new UUID.
 * Sets the header on the response and stores it in AsyncLocalStorage for the logger.
 * @param {import('http').IncomingMessage} req
 * @param {import('http').ServerResponse} res
 * @param {Function} next
 */
export function correlationId(req, res, next) {
  const id = req.headers['x-correlation-id'] || randomUUID();
  res.setHeader('X-Correlation-ID', id);
  als.run({ correlationId: id }, () => {
    next();
  });
}

/**
 * Global error handler middleware.
 * Catches AppError instances and returns structured JSON responses.
 * Unknown errors return 500.
 * @param {Error} err
 * @param {import('http').IncomingMessage} _req
 * @param {import('http').ServerResponse} res
 * @param {Function} _next
 */
export function errorHandler(err, _req, res, _next) {
  if (err instanceof AppError) {
    log.warn({ statusCode: err.statusCode, code: err.code }, err.message);
    res.status(err.statusCode).json(err.toJSON());
  } else {
    log.error({ stack: err.stack }, err.message || 'Internal Server Error');
    res.status(500).json({
      error: 'InternalServerError',
      code: 'INTERNAL_ERROR',
      statusCode: 500,
      message: 'Internal Server Error',
    });
  }
}
