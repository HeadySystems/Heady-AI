/**
 * @module config
 * @description Validated configuration loader.
 * Reads from process.env, validates types, and returns a frozen config object.
 */

/**
 * @typedef {Object} SchemaEntry
 * @property {'string'|'number'|'boolean'|'json'} type - Expected type.
 * @property {string} env - Environment variable name to read.
 * @property {*} [default] - Default value if env var is not set.
 * @property {boolean} [required] - Whether the field is required (default false).
 */

/**
 * Parse a raw string value into the specified type.
 * @param {string} raw - Raw environment variable value.
 * @param {'string'|'number'|'boolean'|'json'} type - Target type.
 * @param {string} key - Config key name (for error messages).
 * @returns {*} Parsed value.
 */
function parseValue(raw, type, key) {
  switch (type) {
    case 'string':
      return raw;
    case 'number': {
      const num = Number(raw);
      if (Number.isNaN(num)) {
        throw new Error(`Config "${key}": expected number, got "${raw}"`);
      }
      return num;
    }
    case 'boolean':
      if (raw === 'true' || raw === '1') return true;
      if (raw === 'false' || raw === '0' || raw === '') return false;
      throw new Error(`Config "${key}": expected boolean, got "${raw}"`);
    case 'json':
      try {
        return JSON.parse(raw);
      } catch {
        throw new Error(`Config "${key}": invalid JSON in env var`);
      }
    default:
      throw new Error(`Config "${key}": unknown type "${type}"`);
  }
}

/**
 * Validate and load configuration from environment variables.
 *
 * @param {Record<string, SchemaEntry>} schema - Configuration schema.
 * @returns {Readonly<Record<string, *>>} Frozen configuration object.
 * @throws {Error} If required fields are missing or types don't match.
 *
 * @example
 * const config = validateConfig({
 *   port: { type: 'number', env: 'PORT', default: 3000 },
 *   dbUrl: { type: 'string', env: 'DATABASE_URL', required: true },
 *   debug: { type: 'boolean', env: 'DEBUG', default: false },
 * });
 */
export function validateConfig(schema) {
  const errors = [];
  const config = {};

  for (const [key, entry] of Object.entries(schema)) {
    const raw = process.env[entry.env];

    if (raw === undefined || raw === '') {
      if (entry.required && entry.default === undefined) {
        errors.push(`"${key}" is required (env: ${entry.env})`);
        continue;
      }
      config[key] = entry.default;
      continue;
    }

    try {
      config[key] = parseValue(raw, entry.type, key);
    } catch (err) {
      errors.push(err.message);
    }
  }

  if (errors.length > 0) {
    throw new Error(`Configuration validation failed:\n  - ${errors.join('\n  - ')}`);
  }

  return Object.freeze(config);
}
