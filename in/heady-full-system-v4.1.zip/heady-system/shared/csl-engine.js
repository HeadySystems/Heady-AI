/**
 * @module csl-engine
 * @description Backward-compatible re-export shim for CSL gate operations.
 * All gate logic now lives in phi-math.js (v4.1.0). This module re-exports
 * those functions and provides helper utilities (dotProduct, magnitude, normalize).
 */

export {
  cosineSimilarity,
  cslAND,
  cslOR,
  cslNOT,
  cslIMPLY,
  cslCONSENSUS,
  cslXOR,
  cslBlend,
  cslGate,
  cslGate as cslGATE,
} from './phi-math.js';

/**
 * Compute the dot product of two vectors.
 * @param {number[]} a - First vector.
 * @param {number[]} b - Second vector.
 * @returns {number} Dot product.
 */
export function dotProduct(a, b) {
  let sum = 0;
  for (let i = 0; i < a.length; i++) {
    sum += a[i] * b[i];
  }
  return sum;
}

/**
 * Compute the magnitude (L2 norm) of a vector.
 * @param {number[]} v - Input vector.
 * @returns {number} Magnitude.
 */
export function magnitude(v) {
  let sum = 0;
  for (let i = 0; i < v.length; i++) {
    sum += v[i] * v[i];
  }
  return Math.sqrt(sum);
}

/**
 * Normalize a vector to unit length.
 * Returns a zero vector if input has zero magnitude.
 * @param {number[]} v - Input vector.
 * @returns {number[]} Unit vector.
 */
export function normalize(v) {
  const mag = magnitude(v);
  if (mag === 0) return new Array(v.length).fill(0);
  return v.map((x) => x / mag);
}
