/**
 * @module errors
 * @description Typed error hierarchy for the Heady system.
 * All errors extend AppError and carry a statusCode and machine-readable code.
 */

/**
 * Base application error.
 * All domain-specific errors extend this class.
 */
export class AppError extends Error {
  /**
   * @param {string} message - Human-readable error message.
   * @param {number} [statusCode=500] - HTTP status code.
   * @param {string} [code='APP_ERROR'] - Machine-readable error code.
   */
  constructor(message, statusCode = 500, code = 'APP_ERROR') {
    super(message);
    this.name = this.constructor.name;
    this.statusCode = statusCode;
    this.code = code;
    Error.captureStackTrace(this, this.constructor);
  }

  /**
   * Serialize to a plain JSON-safe object.
   * @returns {{error: string, code: string, statusCode: number, message: string}}
   */
  toJSON() {
    return {
      error: this.name,
      code: this.code,
      statusCode: this.statusCode,
      message: this.message,
    };
  }
}

/**
 * Resource not found (404).
 */
export class NotFoundError extends AppError {
  /**
   * @param {string} [message='Not Found']
   */
  constructor(message = 'Not Found') {
    super(message, 404, 'NOT_FOUND');
  }
}

/**
 * Validation failure (400).
 */
export class ValidationError extends AppError {
  /**
   * @param {string} [message='Validation Failed']
   */
  constructor(message = 'Validation Failed') {
    super(message, 400, 'VALIDATION_ERROR');
  }
}

/**
 * Authentication / authorization failure (401).
 */
export class AuthError extends AppError {
  /**
   * @param {string} [message='Unauthorized']
   */
  constructor(message = 'Unauthorized') {
    super(message, 401, 'AUTH_ERROR');
  }
}

/**
 * Rate limit exceeded (429).
 */
export class RateLimitError extends AppError {
  /**
   * @param {string} [message='Rate Limit Exceeded']
   */
  constructor(message = 'Rate Limit Exceeded') {
    super(message, 429, 'RATE_LIMIT');
  }
}

/**
 * Coherence drift detected — a component's coherence score has fallen below its threshold.
 */
export class CoherenceDriftError extends AppError {
  /**
   * @param {string} component - Name of the component that drifted.
   * @param {number} currentScore - The current coherence score.
   * @param {number} threshold - The minimum acceptable threshold.
   */
  constructor(component, currentScore, threshold) {
    super(
      `Coherence drift in ${component}: score ${currentScore.toFixed(4)} < threshold ${threshold.toFixed(4)}`,
      503,
      'COHERENCE_DRIFT'
    );
    this.component = component;
    this.currentScore = currentScore;
    this.threshold = threshold;
  }

  toJSON() {
    return {
      ...super.toJSON(),
      component: this.component,
      currentScore: this.currentScore,
      threshold: this.threshold,
    };
  }
}
