/**
 * @module health
 * @description Health check endpoint with coherence scoring.
 * Returns an Express-compatible async request handler.
 */

import { CSL_THRESHOLDS } from './phi-math.js';

/**
 * @typedef {Object} HealthCheckEntry
 * @property {string} name - Check name.
 * @property {() => Promise<{ok: boolean, detail?: *}>} check - Async check function.
 */

/**
 * @typedef {Object} HealthCheckConfig
 * @property {string} service - Service name.
 * @property {string} version - Service version.
 * @property {number} [coherenceThreshold] - Minimum coherence score for healthy status.
 * @property {HealthCheckEntry[]} [checks] - Array of health checks to run.
 */

const startTime = Date.now();

/**
 * Create an Express-compatible health check handler.
 *
 * Runs all checks concurrently. Reports status as healthy/degraded/unhealthy
 * based on the ratio of passing checks compared to the coherence threshold.
 *
 * @param {HealthCheckConfig} config - Health check configuration.
 * @returns {(req: *, res: *) => Promise<void>} Express async handler.
 */
export function createHealthCheck(config) {
  const {
    service,
    version,
    coherenceThreshold = CSL_THRESHOLDS.MEDIUM,
    checks = [],
  } = config;

  return async (_req, res) => {
    const results = await Promise.all(
      checks.map(async ({ name, check }) => {
        const start = Date.now();
        try {
          const result = await check();
          return {
            name,
            ok: result.ok,
            detail: result.detail || null,
            durationMs: Date.now() - start,
          };
        } catch (err) {
          return {
            name,
            ok: false,
            detail: err.message,
            durationMs: Date.now() - start,
          };
        }
      })
    );

    const total = results.length;
    const passed = results.filter((r) => r.ok).length;
    const coherenceScore = total > 0 ? passed / total : 1.0;

    let status;
    if (coherenceScore >= coherenceThreshold) {
      status = 'healthy';
    } else if (coherenceScore >= CSL_THRESHOLDS.MINIMUM) {
      status = 'degraded';
    } else {
      status = 'unhealthy';
    }

    const statusCode = status === 'healthy' ? 200 : status === 'degraded' ? 207 : 503;

    const body = {
      status,
      service,
      version,
      uptime: Math.floor((Date.now() - startTime) / 1000),
      coherenceScore: parseFloat(coherenceScore.toFixed(4)),
      coherenceThreshold,
      checks: results,
    };

    res.status(statusCode).json(body);
  };
}
