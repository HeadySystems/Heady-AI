/**
 * @module phi-math.test
 * @description Tests for phi-math v4.1.0 canonical foundation module.
 * Uses Node.js built-in test runner (node:test) and assert.
 */

import { describe, it } from 'node:test';
import assert from 'node:assert/strict';

import {
  PHI,
  PSI,
  PHI2,
  PHI3,
  FIB,
  fib,
  CSL_THRESHOLDS,
  DEDUP_THRESHOLD,
  COHERENCE_DRIFT_THRESHOLD,
  PRESSURE_LEVELS,
  ALERT_THRESHOLDS,
  phiFusionWeights,
  phiPriorityScore,
  EVICTION_WEIGHTS,
  RESOURCE_WEIGHTS,
  phiResourceWeights,
  phiBackoff,
  fibRetryBackoff,
  phiAdaptiveInterval,
  phiThreshold,
  phiTokenBudgets,
  COMPRESSION_TRIGGER,
  PHI_TEMPERATURE,
  cslGate,
  cslBlend,
  adaptiveTemperature,
  cosineSimilarity,
  cslAND,
  cslOR,
  cslNOT,
  cslIMPLY,
  cslCONSENSUS,
  cslXOR,
  SIZING,
  POOL_SIZES,
  RELEVANCE_GATES,
  phiMultiSplit,
} from '../shared/phi-math.js';

import {
  dotProduct,
  magnitude,
  normalize,
  cslGATE,
  cslGate as cslGateFromEngine,
} from '../shared/csl-engine.js';

const EPSILON = 1e-10;

// ═══════════════════════════════════════════════════════════════════════════════
// CORE CONSTANTS
// ═══════════════════════════════════════════════════════════════════════════════

describe('Core Constants', () => {
  it('PHI equals the golden ratio', () => {
    assert.ok(Math.abs(PHI - 1.6180339887498949) < EPSILON);
  });

  it('PSI equals 1/PHI', () => {
    assert.ok(Math.abs(PSI - 1 / PHI) < EPSILON);
    assert.ok(Math.abs(PSI - (PHI - 1)) < EPSILON);
  });

  it('PHI * PSI equals 1', () => {
    assert.ok(Math.abs(PHI * PSI - 1) < EPSILON);
  });

  it('PHI2 equals PHI + 1', () => {
    assert.ok(Math.abs(PHI2 - (PHI + 1)) < EPSILON);
  });

  it('PHI3 equals 2 * PHI + 1', () => {
    assert.ok(Math.abs(PHI3 - (2 * PHI + 1)) < EPSILON);
  });
});

describe('FIB array', () => {
  it('has 21 elements (index 0 through 20)', () => {
    assert.equal(FIB.length, 21);
  });

  it('starts with 0, 1', () => {
    assert.equal(FIB[0], 0);
    assert.equal(FIB[1], 1);
  });

  it('has correct values at known indices', () => {
    assert.equal(FIB[2], 1);
    assert.equal(FIB[3], 2);
    assert.equal(FIB[4], 3);
    assert.equal(FIB[5], 5);
    assert.equal(FIB[6], 8);
    assert.equal(FIB[7], 13);
    assert.equal(FIB[8], 21);
    assert.equal(FIB[9], 34);
    assert.equal(FIB[10], 55);
    assert.equal(FIB[11], 89);
    assert.equal(FIB[19], 4181);
    assert.equal(FIB[20], 6765);
  });

  it('is frozen', () => {
    assert.ok(Object.isFrozen(FIB));
  });

  it('obeys F(n) = F(n-1) + F(n-2)', () => {
    for (let i = 2; i < FIB.length; i++) {
      assert.equal(FIB[i], FIB[i - 1] + FIB[i - 2]);
    }
  });
});

describe('fib() function', () => {
  it('returns FIB values for indices within array', () => {
    for (let i = 0; i < FIB.length; i++) {
      assert.equal(fib(i), FIB[i]);
    }
  });

  it('computes beyond the FIB array', () => {
    assert.equal(fib(21), 10946);
    assert.equal(fib(25), 75025);
  });

  it('returns 0 for negative indices', () => {
    assert.equal(fib(-1), 0);
    assert.equal(fib(-100), 0);
  });
});

// ═══════════════════════════════════════════════════════════════════════════════
// CSL THRESHOLDS
// ═══════════════════════════════════════════════════════════════════════════════

describe('phiThreshold', () => {
  it('level 0 produces ~0.5 (MINIMUM)', () => {
    assert.ok(Math.abs(phiThreshold(0) - 0.5) < EPSILON);
  });

  it('level 1 produces ~0.691 (LOW)', () => {
    assert.ok(Math.abs(phiThreshold(1) - (1 - 0.5 * PSI)) < EPSILON);
  });

  it('level 2 produces ~0.809 (MEDIUM)', () => {
    assert.ok(Math.abs(phiThreshold(2) - (1 - 0.5 * Math.pow(PSI, 2))) < EPSILON);
  });

  it('level 3 produces ~0.882 (HIGH)', () => {
    assert.ok(Math.abs(phiThreshold(3) - (1 - 0.5 * Math.pow(PSI, 3))) < EPSILON);
  });

  it('level 4 produces ~0.927 (CRITICAL)', () => {
    assert.ok(Math.abs(phiThreshold(4) - (1 - 0.5 * Math.pow(PSI, 4))) < EPSILON);
  });

  it('respects custom spread', () => {
    const t = phiThreshold(2, 0.3);
    const expected = 1 - 0.3 * Math.pow(PSI, 2);
    assert.ok(Math.abs(t - expected) < EPSILON);
  });
});

describe('CSL_THRESHOLDS', () => {
  it('values match phiThreshold(level) for levels 0-4', () => {
    assert.ok(Math.abs(CSL_THRESHOLDS.MINIMUM - phiThreshold(0)) < EPSILON);
    assert.ok(Math.abs(CSL_THRESHOLDS.LOW - phiThreshold(1)) < EPSILON);
    assert.ok(Math.abs(CSL_THRESHOLDS.MEDIUM - phiThreshold(2)) < EPSILON);
    assert.ok(Math.abs(CSL_THRESHOLDS.HIGH - phiThreshold(3)) < EPSILON);
    assert.ok(Math.abs(CSL_THRESHOLDS.CRITICAL - phiThreshold(4)) < EPSILON);
  });

  it('thresholds are in ascending order', () => {
    assert.ok(CSL_THRESHOLDS.MINIMUM < CSL_THRESHOLDS.LOW);
    assert.ok(CSL_THRESHOLDS.LOW < CSL_THRESHOLDS.MEDIUM);
    assert.ok(CSL_THRESHOLDS.MEDIUM < CSL_THRESHOLDS.HIGH);
    assert.ok(CSL_THRESHOLDS.HIGH < CSL_THRESHOLDS.CRITICAL);
  });

  it('is frozen', () => {
    assert.ok(Object.isFrozen(CSL_THRESHOLDS));
  });

  it('MINIMUM is 0.5', () => {
    assert.equal(CSL_THRESHOLDS.MINIMUM, 0.5);
  });
});

describe('DEDUP_THRESHOLD', () => {
  it('is computed as 1 - PSI^6 * 0.5', () => {
    const expected = 1 - Math.pow(PSI, 6) * 0.5;
    assert.ok(Math.abs(DEDUP_THRESHOLD - expected) < EPSILON);
  });

  it('is above CRITICAL', () => {
    assert.ok(DEDUP_THRESHOLD > CSL_THRESHOLDS.CRITICAL);
  });
});

describe('COHERENCE_DRIFT_THRESHOLD', () => {
  it('equals CSL_THRESHOLDS.MEDIUM', () => {
    assert.equal(COHERENCE_DRIFT_THRESHOLD, CSL_THRESHOLDS.MEDIUM);
  });
});

// ═══════════════════════════════════════════════════════════════════════════════
// PRESSURE & ALERTS
// ═══════════════════════════════════════════════════════════════════════════════

describe('PRESSURE_LEVELS', () => {
  it('has NOMINAL, ELEVATED, HIGH, CRITICAL with min/max ranges', () => {
    assert.ok('min' in PRESSURE_LEVELS.NOMINAL && 'max' in PRESSURE_LEVELS.NOMINAL);
    assert.ok('min' in PRESSURE_LEVELS.ELEVATED && 'max' in PRESSURE_LEVELS.ELEVATED);
    assert.ok('min' in PRESSURE_LEVELS.HIGH && 'max' in PRESSURE_LEVELS.HIGH);
    assert.ok('min' in PRESSURE_LEVELS.CRITICAL && 'max' in PRESSURE_LEVELS.CRITICAL);
  });

  it('NOMINAL starts at 0, CRITICAL max is 1', () => {
    assert.equal(PRESSURE_LEVELS.NOMINAL.min, 0);
    assert.equal(PRESSURE_LEVELS.CRITICAL.max, 1.0);
  });

  it('NOMINAL.max equals PSI^2', () => {
    assert.ok(Math.abs(PRESSURE_LEVELS.NOMINAL.max - Math.pow(PSI, 2)) < EPSILON);
  });

  it('ELEVATED range uses PSI^2 to PSI', () => {
    assert.ok(Math.abs(PRESSURE_LEVELS.ELEVATED.min - Math.pow(PSI, 2)) < EPSILON);
    assert.ok(Math.abs(PRESSURE_LEVELS.ELEVATED.max - PSI) < EPSILON);
  });

  it('is frozen (including nested objects)', () => {
    assert.ok(Object.isFrozen(PRESSURE_LEVELS));
    assert.ok(Object.isFrozen(PRESSURE_LEVELS.NOMINAL));
  });
});

describe('ALERT_THRESHOLDS', () => {
  it('warning equals PSI (~0.618)', () => {
    assert.ok(Math.abs(ALERT_THRESHOLDS.warning - PSI) < EPSILON);
  });

  it('caution equals 1 - PSI^2', () => {
    assert.ok(Math.abs(ALERT_THRESHOLDS.caution - (1 - Math.pow(PSI, 2))) < EPSILON);
  });

  it('critical equals 1 - PSI^3', () => {
    assert.ok(Math.abs(ALERT_THRESHOLDS.critical - (1 - Math.pow(PSI, 3))) < EPSILON);
  });

  it('exceeded equals 1 - PSI^4', () => {
    assert.ok(Math.abs(ALERT_THRESHOLDS.exceeded - (1 - Math.pow(PSI, 4))) < EPSILON);
  });

  it('hard_max is 1.0', () => {
    assert.equal(ALERT_THRESHOLDS.hard_max, 1.0);
  });

  it('thresholds are in non-decreasing order', () => {
    assert.ok(ALERT_THRESHOLDS.warning <= ALERT_THRESHOLDS.caution);
    assert.ok(ALERT_THRESHOLDS.caution <= ALERT_THRESHOLDS.critical);
    assert.ok(ALERT_THRESHOLDS.critical < ALERT_THRESHOLDS.exceeded);
    assert.ok(ALERT_THRESHOLDS.exceeded < ALERT_THRESHOLDS.hard_max);
  });
});

// ═══════════════════════════════════════════════════════════════════════════════
// FUSION & SCORING
// ═══════════════════════════════════════════════════════════════════════════════

describe('phiFusionWeights', () => {
  it('returns empty for n=0', () => {
    assert.deepEqual(phiFusionWeights(0), []);
  });

  it('returns [1] for n=1', () => {
    const w = phiFusionWeights(1);
    assert.equal(w.length, 1);
    assert.ok(Math.abs(w[0] - 1) < EPSILON);
  });

  it('sums to 1 for any n', () => {
    for (const n of [2, 3, 5, 10]) {
      const w = phiFusionWeights(n);
      const sum = w.reduce((a, b) => a + b, 0);
      assert.ok(Math.abs(sum - 1) < EPSILON, `n=${n}: sum=${sum}`);
    }
  });

  it('weights are in descending order', () => {
    const w = phiFusionWeights(5);
    for (let i = 0; i < w.length - 1; i++) {
      assert.ok(w[i] > w[i + 1]);
    }
  });

  it('weight ratio is PSI', () => {
    const w = phiFusionWeights(4);
    for (let i = 0; i < w.length - 1; i++) {
      assert.ok(Math.abs(w[i + 1] / w[i] - PSI) < EPSILON);
    }
  });
});

describe('phiPriorityScore', () => {
  it('returns 0 for no factors', () => {
    assert.equal(phiPriorityScore(), 0);
  });

  it('returns the factor itself for a single factor', () => {
    assert.ok(Math.abs(phiPriorityScore(0.8) - 0.8) < EPSILON);
  });

  it('produces a weighted average for multiple factors', () => {
    const score = phiPriorityScore(1.0, 0.5);
    const w = phiFusionWeights(2);
    const expected = w[0] * 1.0 + w[1] * 0.5;
    assert.ok(Math.abs(score - expected) < EPSILON);
  });

  it('score is between min and max factor values', () => {
    const score = phiPriorityScore(0.2, 0.8, 0.5);
    assert.ok(score >= 0.2);
    assert.ok(score <= 0.8);
  });
});

describe('EVICTION_WEIGHTS', () => {
  it('has importance, recency, relevance', () => {
    assert.ok('importance' in EVICTION_WEIGHTS);
    assert.ok('recency' in EVICTION_WEIGHTS);
    assert.ok('relevance' in EVICTION_WEIGHTS);
  });

  it('sums to 1', () => {
    const sum = EVICTION_WEIGHTS.importance + EVICTION_WEIGHTS.recency + EVICTION_WEIGHTS.relevance;
    assert.ok(Math.abs(sum - 1) < EPSILON);
  });

  it('importance > recency > relevance', () => {
    assert.ok(EVICTION_WEIGHTS.importance > EVICTION_WEIGHTS.recency);
    assert.ok(EVICTION_WEIGHTS.recency > EVICTION_WEIGHTS.relevance);
  });
});

describe('RESOURCE_WEIGHTS', () => {
  it('has hot, warm, cold, reserve, governance', () => {
    assert.ok('hot' in RESOURCE_WEIGHTS);
    assert.ok('warm' in RESOURCE_WEIGHTS);
    assert.ok('cold' in RESOURCE_WEIGHTS);
    assert.ok('reserve' in RESOURCE_WEIGHTS);
    assert.ok('governance' in RESOURCE_WEIGHTS);
  });

  it('sums to 1', () => {
    const sum = RESOURCE_WEIGHTS.hot + RESOURCE_WEIGHTS.warm + RESOURCE_WEIGHTS.cold +
                RESOURCE_WEIGHTS.reserve + RESOURCE_WEIGHTS.governance;
    assert.ok(Math.abs(sum - 1) < EPSILON);
  });

  it('hot is largest, governance is smallest', () => {
    assert.ok(RESOURCE_WEIGHTS.hot > RESOURCE_WEIGHTS.warm);
    assert.ok(RESOURCE_WEIGHTS.warm > RESOURCE_WEIGHTS.cold);
    assert.ok(RESOURCE_WEIGHTS.cold > RESOURCE_WEIGHTS.reserve);
    assert.ok(RESOURCE_WEIGHTS.reserve > RESOURCE_WEIGHTS.governance);
  });
});

describe('phiResourceWeights', () => {
  it('is equivalent to phiFusionWeights', () => {
    const fw = phiFusionWeights(5);
    const rw = phiResourceWeights(5);
    for (let i = 0; i < fw.length; i++) {
      assert.ok(Math.abs(fw[i] - rw[i]) < EPSILON);
    }
  });
});

// ═══════════════════════════════════════════════════════════════════════════════
// BACKOFF & TIMING
// ═══════════════════════════════════════════════════════════════════════════════

describe('phiBackoff', () => {
  it('returns ~baseMs at attempt 0 (jitter=false)', () => {
    assert.equal(phiBackoff(0, 1000, 60000, false), 1000);
  });

  it('increases by PHI per attempt (jitter=false)', () => {
    const d1 = phiBackoff(1, 1000, 60000, false);
    const d2 = phiBackoff(2, 1000, 60000, false);
    assert.equal(d1, Math.round(1000 * PHI));
    assert.equal(d2, Math.round(1000 * PHI * PHI));
  });

  it('caps at maxMs (jitter=false)', () => {
    assert.equal(phiBackoff(100, 1000, 60000, false), 60000);
    assert.equal(phiBackoff(100, 1000, 5000, false), 5000);
  });

  it('returns integer values', () => {
    assert.ok(Number.isInteger(phiBackoff(3)));
    assert.ok(Number.isInteger(phiBackoff(0, 1000, 60000, false)));
  });

  it('with jitter=true stays within ±PSI² (~38.2%) range', () => {
    const base = phiBackoff(2, 1000, 60000, false);
    const psi2 = Math.pow(PSI, 2);
    const results = [];
    for (let i = 0; i < 100; i++) {
      results.push(phiBackoff(2, 1000, 60000, true));
    }
    for (const r of results) {
      assert.ok(r >= Math.round(base * (1 - psi2)) - 1, `${r} too low (min ${Math.round(base * (1 - psi2))})`);
      assert.ok(r <= Math.round(base * (1 + psi2)) + 1, `${r} too high (max ${Math.round(base * (1 + psi2))})`);
    }
  });

  it('respects custom baseMs (jitter=false)', () => {
    assert.equal(phiBackoff(0, 500, 60000, false), 500);
  });
});

describe('fibRetryBackoff', () => {
  it('returns FIB[4..8] * multiplier for count=5', () => {
    const delays = fibRetryBackoff(5, 100);
    assert.equal(delays.length, 5);
    assert.equal(delays[0], fib(4) * 100);  // 3 * 100 = 300
    assert.equal(delays[1], fib(5) * 100);  // 5 * 100 = 500
    assert.equal(delays[2], fib(6) * 100);  // 8 * 100 = 800
    assert.equal(delays[3], fib(7) * 100);  // 13 * 100 = 1300
    assert.equal(delays[4], fib(8) * 100);  // 21 * 100 = 2100
  });

  it('uses default count=5 and multiplier=100', () => {
    const delays = fibRetryBackoff();
    assert.equal(delays.length, 5);
    assert.equal(delays[0], 300);  // FIB[4] * 100
  });
});

describe('phiAdaptiveInterval', () => {
  it('healthy: increases by PHI (capped at base*PHI3)', () => {
    const result = phiAdaptiveInterval(1000, true, 500);
    assert.ok(Math.abs(result - 500 * PHI) < EPSILON || result === 1000 * PHI3);
  });

  it('healthy: caps at baseMs * PHI3', () => {
    const result = phiAdaptiveInterval(1000, true, 5000);
    assert.ok(Math.abs(result - 1000 * PHI3) < EPSILON);
  });

  it('unhealthy: decreases by PSI (floored at base*PSI)', () => {
    const result = phiAdaptiveInterval(1000, false, 5000);
    assert.ok(Math.abs(result - 5000 * PSI) < EPSILON);
  });

  it('unhealthy: floors at baseMs * PSI', () => {
    const result = phiAdaptiveInterval(1000, false, 100);
    assert.ok(Math.abs(result - 1000 * PSI) < EPSILON);
  });
});

// ═══════════════════════════════════════════════════════════════════════════════
// TOKEN BUDGETS
// ═══════════════════════════════════════════════════════════════════════════════

describe('phiTokenBudgets', () => {
  it('returns {working, session, memory, artifacts}', () => {
    const b = phiTokenBudgets(8192);
    assert.ok('working' in b);
    assert.ok('session' in b);
    assert.ok('memory' in b);
    assert.ok('artifacts' in b);
  });

  it('working equals base', () => {
    assert.equal(phiTokenBudgets(8192).working, 8192);
    assert.equal(phiTokenBudgets(4096).working, 4096);
  });

  it('session equals round(base * PHI2)', () => {
    const b = phiTokenBudgets(8192);
    assert.equal(b.session, Math.round(8192 * PHI2));
  });

  it('memory equals round(base * PHI2 * PHI2)', () => {
    const b = phiTokenBudgets(8192);
    assert.equal(b.memory, Math.round(8192 * PHI2 * PHI2));
  });

  it('artifacts equals round(base * PHI^6)', () => {
    const b = phiTokenBudgets(8192);
    assert.equal(b.artifacts, Math.round(8192 * Math.pow(PHI, 6)));
  });

  it('tiers increase: working < session < memory < artifacts', () => {
    const b = phiTokenBudgets(8192);
    assert.ok(b.working < b.session);
    assert.ok(b.session < b.memory);
    assert.ok(b.memory < b.artifacts);
  });
});

describe('COMPRESSION_TRIGGER', () => {
  it('equals 1 - PSI^4', () => {
    assert.ok(Math.abs(COMPRESSION_TRIGGER - (1 - Math.pow(PSI, 4))) < EPSILON);
  });
});

describe('PHI_TEMPERATURE', () => {
  it('equals PSI^3', () => {
    assert.ok(Math.abs(PHI_TEMPERATURE - Math.pow(PSI, 3)) < EPSILON);
  });
});

// ═══════════════════════════════════════════════════════════════════════════════
// CSL GATES
// ═══════════════════════════════════════════════════════════════════════════════

describe('cslGate', () => {
  it('returns value * sigmoid((cosScore - tau) / temp)', () => {
    const value = 10;
    const cosScore = 0.9;
    const tau = 0.5;
    const temp = PHI_TEMPERATURE;
    const sigmoid = 1 / (1 + Math.exp(-(cosScore - tau) / temp));
    const expected = value * sigmoid;
    assert.ok(Math.abs(cslGate(value, cosScore, tau) - expected) < EPSILON);
  });

  it('returns ~value when cosScore >> tau', () => {
    const result = cslGate(10, 0.99, 0.1);
    assert.ok(result > 9.5, `expected > 9.5, got ${result}`);
  });

  it('returns ~0 when cosScore << tau', () => {
    const result = cslGate(10, 0.01, 0.99);
    assert.ok(result < 0.5, `expected < 0.5, got ${result}`);
  });

  it('uses PHI_TEMPERATURE as default temp', () => {
    const r1 = cslGate(5, 0.7, 0.5);
    const r2 = cslGate(5, 0.7, 0.5, PHI_TEMPERATURE);
    assert.ok(Math.abs(r1 - r2) < EPSILON);
  });
});

describe('cslBlend', () => {
  it('blends between weightLow and weightHigh', () => {
    const result = cslBlend(10, 2, 0.9, 0.5);
    assert.ok(result > 2);
    assert.ok(result <= 10);
  });

  it('returns ~weightHigh when cosScore >> tau', () => {
    const result = cslBlend(10, 2, 0.99, 0.1);
    assert.ok(result > 9, `expected > 9, got ${result}`);
  });

  it('returns ~weightLow when cosScore << tau', () => {
    const result = cslBlend(10, 2, 0.01, 0.99);
    assert.ok(result < 3, `expected < 3, got ${result}`);
  });
});

describe('adaptiveTemperature', () => {
  it('returns PHI_TEMPERATURE when entropy is 0', () => {
    assert.ok(Math.abs(adaptiveTemperature(0, 10) - PHI_TEMPERATURE) < EPSILON);
  });

  it('returns PHI_TEMPERATURE * (1 + PHI) when entropy equals maxEntropy', () => {
    const expected = PHI_TEMPERATURE * (1 + PHI);
    assert.ok(Math.abs(adaptiveTemperature(10, 10) - expected) < EPSILON);
  });

  it('increases with entropy', () => {
    const low = adaptiveTemperature(2, 10);
    const high = adaptiveTemperature(8, 10);
    assert.ok(high > low);
  });

  it('formula: PHI_TEMPERATURE * (1 + ratio * PHI)', () => {
    const entropy = 5;
    const maxEntropy = 10;
    const expected = PHI_TEMPERATURE * (1 + (entropy / maxEntropy) * PHI);
    assert.ok(Math.abs(adaptiveTemperature(entropy, maxEntropy) - expected) < EPSILON);
  });
});

describe('cosineSimilarity', () => {
  it('returns 1 for identical vectors', () => {
    const v = [1, 2, 3, 4, 5];
    assert.ok(Math.abs(cosineSimilarity(v, v) - 1) < EPSILON);
  });

  it('returns -1 for opposite vectors', () => {
    const a = [1, 0, 0];
    const b = [-1, 0, 0];
    assert.ok(Math.abs(cosineSimilarity(a, b) - (-1)) < EPSILON);
  });

  it('returns 0 for orthogonal vectors', () => {
    const a = [1, 0, 0];
    const b = [0, 1, 0];
    assert.ok(Math.abs(cosineSimilarity(a, b)) < EPSILON);
  });

  it('returns 0 when either vector is zero', () => {
    assert.equal(cosineSimilarity([0, 0, 0], [1, 2, 3]), 0);
    assert.equal(cosineSimilarity([1, 2, 3], [0, 0, 0]), 0);
  });
});

describe('cslAND', () => {
  it('returns cosine similarity', () => {
    const a = [1, 2, 3];
    const b = [4, 5, 6];
    assert.ok(Math.abs(cslAND(a, b) - cosineSimilarity(a, b)) < EPSILON);
  });
});

describe('cslOR', () => {
  it('returns normalized superposition', () => {
    const a = [1, 0, 0];
    const b = [0, 1, 0];
    const result = cslOR(a, b);
    const mag = Math.sqrt(result.reduce((s, v) => s + v * v, 0));
    assert.ok(Math.abs(mag - 1) < EPSILON);
  });
});

describe('cslNOT', () => {
  it('removes component along b', () => {
    const a = [1, 1, 0];
    const b = [1, 0, 0];
    const result = cslNOT(a, b);
    assert.ok(Math.abs(result[0]) < EPSILON);
    assert.ok(Math.abs(result[1] - 1) < EPSILON);
    assert.ok(Math.abs(result[2]) < EPSILON);
  });

  it('returns copy of a if b is zero', () => {
    const a = [1, 2, 3];
    const result = cslNOT(a, [0, 0, 0]);
    assert.deepEqual(result, [1, 2, 3]);
  });
});

describe('cslIMPLY', () => {
  it('projects a onto b', () => {
    const a = [3, 4, 0];
    const b = [1, 0, 0];
    const result = cslIMPLY(a, b);
    assert.ok(Math.abs(result[0] - 3) < EPSILON);
    assert.ok(Math.abs(result[1]) < EPSILON);
    assert.ok(Math.abs(result[2]) < EPSILON);
  });

  it('returns zero vector if b is zero', () => {
    const result = cslIMPLY([1, 2, 3], [0, 0, 0]);
    assert.deepEqual(result, [0, 0, 0]);
  });
});

describe('cslCONSENSUS', () => {
  it('returns empty for empty input', () => {
    assert.deepEqual(cslCONSENSUS([]), []);
  });

  it('returns normalized centroid', () => {
    const v1 = [1, 0, 0];
    const v2 = [0, 1, 0];
    const result = cslCONSENSUS([v1, v2]);
    const mag = Math.sqrt(result.reduce((s, v) => s + v * v, 0));
    assert.ok(Math.abs(mag - 1) < EPSILON);
  });

  it('uses phiFusionWeights by default', () => {
    const v1 = [1, 0, 0];
    const v2 = [0, 1, 0];
    const result = cslCONSENSUS([v1, v2]);
    // With phi weights, first vector gets more weight
    assert.ok(result[0] > result[1]);
  });

  it('respects custom weights', () => {
    const v1 = [1, 0, 0];
    const v2 = [0, 1, 0];
    const result = cslCONSENSUS([v1, v2], [0.1, 0.9]);
    // Second vector gets more weight
    assert.ok(result[1] > result[0]);
  });
});

describe('cslXOR', () => {
  it('produces a result vector for orthogonal inputs', () => {
    const a = [1, 0, 0];
    const b = [0, 1, 0];
    const result = cslXOR(a, b);
    assert.equal(result.length, 3);
  });

  it('XOR of identical vectors has low magnitude (high overlap removed)', () => {
    const a = [1, 2, 3];
    const result = cslXOR(a, a);
    const mag = Math.sqrt(result.reduce((s, v) => s + v * v, 0));
    // Identical vectors → OR = normalized(2a), AND = 1.0, 
    // projection removes most content
    assert.ok(mag < 1.0, `expected low magnitude, got ${mag}`);
  });

  it('XOR of dissimilar vectors retains content', () => {
    const a = [1, 0, 0];
    const b = [0, 0, 1];
    const result = cslXOR(a, b);
    const mag = Math.sqrt(result.reduce((s, v) => s + v * v, 0));
    assert.ok(mag > 0.1, `expected some magnitude, got ${mag}`);
  });
});

// ═══════════════════════════════════════════════════════════════════════════════
// SIZING
// ═══════════════════════════════════════════════════════════════════════════════

describe('SIZING', () => {
  it('values match canonical Fibonacci assignments', () => {
    assert.equal(SIZING.FAILURE_THRESHOLD, fib(5));   // 5
    assert.equal(SIZING.BATCH_EVICTION, fib(6));      // 8
    assert.equal(SIZING.MAX_CONCURRENT, fib(6));      // 8
    assert.equal(SIZING.SMALL_LIMIT, fib(7));         // 13
    assert.equal(SIZING.HNSW_M, fib(8));              // 21
    assert.equal(SIZING.RERANK_TOP_K, fib(8));        // 21
    assert.equal(SIZING.SLIDING_WINDOW, fib(9));      // 34
    assert.equal(SIZING.MAX_ENTITIES, fib(10));       // 55
    assert.equal(SIZING.RETENTION_DAYS, fib(11));     // 89
    assert.equal(SIZING.EF_SEARCH, fib(11));          // 89
    assert.equal(SIZING.EF_CONSTRUCTION, fib(12));    // 144
    assert.equal(SIZING.QUEUE_DEPTH, fib(13));        // 233
    assert.equal(SIZING.PATTERN_STORE, fib(14));      // 377
    assert.equal(SIZING.CACHE_SIZE, fib(16));         // 987
    assert.equal(SIZING.HISTORY_BUFFER, fib(17));     // 1597
    assert.equal(SIZING.LARGE_CACHE, fib(20));        // 6765
  });

  it('is frozen', () => {
    assert.ok(Object.isFrozen(SIZING));
  });
});

describe('POOL_SIZES', () => {
  it('min equals fib(3)', () => {
    assert.equal(POOL_SIZES.min, fib(3));
  });

  it('max equals fib(7)', () => {
    assert.equal(POOL_SIZES.max, fib(7));
  });
});

describe('RELEVANCE_GATES', () => {
  it('include equals PSI^2', () => {
    assert.ok(Math.abs(RELEVANCE_GATES.include - Math.pow(PSI, 2)) < EPSILON);
  });

  it('boost equals PSI', () => {
    assert.ok(Math.abs(RELEVANCE_GATES.boost - PSI) < EPSILON);
  });

  it('inject equals PSI + 0.1', () => {
    assert.ok(Math.abs(RELEVANCE_GATES.inject - (PSI + 0.1)) < EPSILON);
  });

  it('gates are in ascending order', () => {
    assert.ok(RELEVANCE_GATES.include < RELEVANCE_GATES.boost);
    assert.ok(RELEVANCE_GATES.boost < RELEVANCE_GATES.inject);
  });
});

// ═══════════════════════════════════════════════════════════════════════════════
// BACKWARD COMPATIBILITY
// ═══════════════════════════════════════════════════════════════════════════════

describe('phiMultiSplit', () => {
  it('returns empty for n=0', () => {
    assert.deepEqual(phiMultiSplit(100, 0), []);
  });

  it('returns [whole] for n=1', () => {
    assert.deepEqual(phiMultiSplit(100, 1), [100]);
  });

  it('parts sum to whole', () => {
    for (const [whole, n] of [[100, 3], [1000, 5], [8192, 4], [1, 3]]) {
      const parts = phiMultiSplit(whole, n);
      assert.equal(parts.length, n);
      assert.equal(parts.reduce((a, b) => a + b, 0), whole);
    }
  });

  it('parts are in descending order', () => {
    const parts = phiMultiSplit(1000, 5);
    for (let i = 0; i < parts.length - 1; i++) {
      assert.ok(parts[i] >= parts[i + 1]);
    }
  });

  it('all parts are non-negative integers', () => {
    const parts = phiMultiSplit(10, 7);
    for (const p of parts) {
      assert.ok(Number.isInteger(p));
      assert.ok(p >= 0);
    }
  });
});

// ═══════════════════════════════════════════════════════════════════════════════
// CSL-ENGINE SHIM
// ═══════════════════════════════════════════════════════════════════════════════

describe('csl-engine.js shim', () => {
  it('cslGATE is re-exported and works', () => {
    const result = cslGATE(10, 0.9, 0.5);
    assert.ok(result > 8, `expected > 8, got ${result}`);
  });

  it('cslGATE and cslGate are the same function', () => {
    const r1 = cslGATE(5, 0.7, 0.3);
    const r2 = cslGateFromEngine(5, 0.7, 0.3);
    assert.ok(Math.abs(r1 - r2) < EPSILON);
  });

  it('dotProduct computes correctly', () => {
    assert.equal(dotProduct([1, 2, 3], [4, 5, 6]), 32);
  });

  it('magnitude computes L2 norm', () => {
    assert.ok(Math.abs(magnitude([3, 4]) - 5) < EPSILON);
  });

  it('normalize produces unit vector', () => {
    const n = normalize([3, 4]);
    const mag = Math.sqrt(n[0] * n[0] + n[1] * n[1]);
    assert.ok(Math.abs(mag - 1) < EPSILON);
  });

  it('normalize of zero vector returns zero vector', () => {
    const n = normalize([0, 0, 0]);
    assert.deepEqual(n, [0, 0, 0]);
  });
});
